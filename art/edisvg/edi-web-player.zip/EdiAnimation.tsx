"use client";
import { useEffect, useRef, useState } from "react";
import { mountWebAnimation } from "./edi-web-player.mjs";

export default function EdiAnimation({ src = "/animation.edi-animation.json", title = "Animação" }) {
  const host = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    if (!host.current) return;
    const controller = new AbortController();
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.style.width = "100%";
    svg.style.height = "100%";
    svg.setAttribute("aria-hidden", "true");
    host.current.replaceChildren(svg);
    setFailed(false);
    void (async () => {
      const response = await fetch(src, { signal: controller.signal });
      if (!response.ok) throw new Error("Arte indisponível.");
      await mountWebAnimation(svg, await response.text(), {
        signal: controller.signal,
        onError: () => { if (!controller.signal.aborted) setFailed(true); }
      });
    })().catch(() => { if (!controller.signal.aborted) setFailed(true); });
    return () => { controller.abort(); svg.remove(); };
  }, [src]);
  return <div role="img" aria-label={title} style={{ width: "100%", aspectRatio: "1" }}>
    <div ref={host} style={{ width: "100%", height: "100%" }} />
    {failed && <span role="status">Arte indisponível.</span>}
  </div>;
}
