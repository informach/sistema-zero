# Player web ediSVG

Este pacote funciona em aplicativos web com JavaScript, TypeScript, React ou outros frameworks.
Não depende do Sistema Zero, Electron, conta ou licença do editor. Não é um pacote publicado no npm.

Exporte a arte em "Animação para web" no ediSVG e coloque o arquivo como animation.edi-animation.json
ao lado dos exemplos. Sirva esta pasta por HTTP, com módulos .mjs como text/javascript. Abrir o HTML
diretamente pelo sistema de arquivos não funciona por causa das regras de módulos do navegador.

O exemplo HTML usa o player uma vez por aplicativo, com sessões independentes para cada SVG.
O exemplo React usa a versão de React já instalada no aplicativo e é uma fronteira cliente para
Next.js. Cada montagem cria seu SVG e o descarta ao sair, inclusive no StrictMode. Ajuste o caminho
da arte à pasta pública do aplicativo. Passe somente URLs de mídia confiáveis e valide uploads com
normalizeWebAnimation no servidor. O arquivo é declarativo, sem JavaScript da arte.

mountWebAnimation recebe SVG, arte e opções. O retorno oferece play, pause, reset, setInput,
setInputs, trigger, setMachine, inspect e destroy. Inputs e máquinas usam seus nomes públicos do
ediSVG; consulte readWebAnimation antes de ligar uma integração. Eventos gráficos não autorizam
pagamentos, recompensas ou outras decisões de servidor.

Por padrão a arte respeita movimento reduzido e pausa fora da tela. Defina as dimensões do host
para evitar mudança de layout. O PNG incorporado é a reserva estática e pode ser extraído com
webAnimationPoster no servidor. O módulo edi-web-data.mjs não precisa de DOM. Não monte um segundo
runtime para cada arquivo: importe edi-web-player.mjs uma vez. Layouts usam WASM incorporado;
quando houver CSP, permita wasm-unsafe-eval, sem liberar unsafe-eval ou scripts enviados no upload.
Fontes e imagens incorporadas seguem os limites e verificações do formato edi-animation v1.

Mantenha os módulos, declarações e THIRD_PARTY_LICENSES.txt juntos ao redistribuir. O manifesto
registra hashes dos arquivos. Nenhum arquivo inclui dados de conta ou código de servidor.
