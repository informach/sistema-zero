const fs=require('node:fs');
let build=fs.readFileSync('.cache/build-cache-content-profiles.ts','utf8').replaceAll('47e21b13a0fb94995d24bf4d0fc041af2d0de952','822462a4858fb3224434147f7f8b814189d40373').replaceAll('cache-content-profile-bundles','cache-pressure-profile-bundles');
fs.writeFileSync('.cache/build-cache-pressure-profiles.ts',build,{flag:'wx'});
let source=fs.readFileSync('.cache/run-cache-content-ab.cjs','utf8').replaceAll('47e21b13a0fb94995d24bf4d0fc041af2d0de952','822462a4858fb3224434147f7f8b814189d40373').replaceAll('cache-content-profile-bundles','cache-pressure-profile-bundles').replaceAll('build-cache-content-profiles.ts','build-cache-pressure-profiles.ts').replaceAll('pinta-cache-content','pinta-cache-pressure');
function replace(needle,next){if(source.split(needle).length!==2)throw Error('Benchmark changed: '+needle);source=source.replace(needle,next)}
replace('moves=api.countGridMoves(),sorted=', 'moves=api.countGridMoves(),draws=api.countGridDraws(),sorted=');
replace('return{metadata,times,pixels,moves,cache:', 'return{metadata,times,pixels,moves,draws,cache:');
replace('moves:selected[0].moves}', 'moves:selected[0].moves,draws:selected[0].draws,cache:selected[0].cache}');
fs.writeFileSync('.cache/run-cache-pressure-ab.cjs',source,{flag:'wx'});console.log('Prepared actual 822/current pressure lab');
