import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { buildPythonRuntimeDistribution } from '../packages/studio/scripts/build-python-runtime'
import meta from '../packages/studio/scripts/python/stdlib-manifest.json'

const proof = 'C:/Users/tocha/projects/sistema-zero-pinta-py-core-20261122/.cache/pinta-browser-review'
const result = await buildPythonRuntimeDistribution({
  vendorDirectory: resolve('.cache/pinta-integrated-runtime/vendor'),
  outputDirectory: resolve('.cache/pinta-integrated-runtime/distributions'),
  standardLibrary: {
    path: `${proof}/stdlib-compiled.zip`,
    sha256: meta.sha256,
    recipe: meta.recipe,
  },
})
const sha = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex')
for (const file of result.manifest.files) {
  const bytes = await readFile(resolve(result.directory, file.path))
  if (bytes.byteLength !== file.bytes || sha(bytes) !== file.sha256)
    throw Error(`Invalid immutable artifact: ${file.path}`)
}
const report = {
  at: new Date().toISOString(),
  builder: Bun.version,
  head: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8', windowsHide: true }).trim(),
  directory: result.directory,
  hash: result.hash,
  files: result.manifest.files.length,
  totalBytes: result.manifest.files.reduce((sum, file) => sum + file.bytes, 0),
  allFilesRehashed: true,
  activated: false,
}
await writeFile('.cache/pinta-integrated-runtime/build-report.json', `${JSON.stringify(report, null, 2)}\n`)
console.log(JSON.stringify(report))
