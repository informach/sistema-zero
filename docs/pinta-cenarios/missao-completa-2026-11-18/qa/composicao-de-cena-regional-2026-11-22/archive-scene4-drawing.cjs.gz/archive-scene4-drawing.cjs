const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const baseline='5a9c8cfe2',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/composicao-de-cena-regional-2026-11-22/';
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex'),read=name=>fs.readFileSync('.cache/scene4-drawing-'+name+'.log','utf8');
for(const [name,count]of [['pinta-full',2741],['core-full',3215],['focused',13]]){const text=read(name);if(!text.includes(count+' pass')||!text.includes('0 fail')||/[1-9]\d* skip/.test(text))throw Error(name+' incomplete');}
for(const name of ['core-types','pinta-types','studio-types','diff'])if(read(name).trim())throw Error(name+' not clean');
if(!read('biome').includes('Checked 5 files'))throw Error('Lint missing');
const old=JSON.parse(fs.readFileSync('.cache/scene4-drawing-equivalence.json'));if(old.comparisons!==96||!old.legacyRgbaIdentical||!old.coreEmittedJavaScriptIdentical)throw Error('Legacy proof missing');
const rows=suites=>suites.flatMap(s=>[...(s.specs||[]).flatMap(s=>s.tests),...rows(s.suites||[])]);
const reports=[['packages/studio/.cache/pinta-physical-regions-results/report.json',59,'physical-report.json'],['packages/studio/.cache/pinta-integration-results/report.json',12,'integration-report.json']];
const attachments=[];
for(const [file,expected]of reports){const report=JSON.parse(fs.readFileSync(file));if(report.stats.expected!==expected||report.stats.unexpected||report.stats.skipped||report.stats.flaky||rows(report.suites).some(test=>test.results.length!==1||test.results[0].status!=='passed'))throw Error('Browser failed '+file);for(const test of rows(report.suites))for(const a of test.results[0].attachments||[])if(a.name==='vila-scene4-render.png')attachments.push(a);}
if(attachments.length!==2)throw Error('PNG evidence missing');
fs.mkdirSync(out,{recursive:true});const records=[];
function add(raw,name){const bytes=zlib.gzipSync(raw),file=name+'.gz';fs.writeFileSync(out+file,bytes,{flag:'wx'});records.push({file,bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)});}
for(const name of ['focused','pinta-full','core-full','core-types','pinta-types','studio-types','biome','browser-focused','browser','integration-browser','diff'])add(Buffer.from(read(name)),name+'.log');
for(const [file,,name]of reports)add(fs.readFileSync(file),name);
for(const [index,a]of attachments.entries()){const raw=a.path?fs.readFileSync(a.path):Buffer.from(a.body,'base64');if(raw.subarray(1,4).toString()!=='PNG')throw Error('Invalid PNG');fs.writeFileSync('.cache/scene4-vila-render-'+index+'.png',raw);add(raw,'vila-scene4-render-'+index+'.png');}
for(const name of ['scene4-drawing-equivalence.ts','scene4-drawing-equivalence.json','scene4-drawing-equivalence.log','scene4-render-before.ts','scene4-render-before.log','archive-scene4-drawing.cjs'])add(fs.readFileSync('.cache/'+name),name);
const files=[...new Set([...cp.execFileSync('git',['diff','--name-only','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n')].filter(Boolean))];
const sources=files.map(file=>({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline+':'+file]).status===0?{previousSha256:sha(cp.execFileSync('git',['show',baseline+':'+file]))}:{})}));
const count=text=>({pass:Number(text.match(/(\d+) pass/)?.[1]),fail:0,skipped:0,assertions:Number(text.match(/(\d+) expect\(\) calls/)?.[1]),files:Number(text.match(/across (\d+) files/)?.[1])});
fs.writeFileSync(out+'index.json',JSON.stringify({baseline,records,sources,pinta:count(read('pinta-full')),core:count(read('core-full')),focused:count(read('focused')),rgba:{regionalDense:192,legacyHistorical:96,browserRealImages:14},browser:{pass:71,physical:59,integration:12,retries:0,profiles:['desktop','cpu-4x']},publicScene4:false,png5:false,gameplayRuntime4:false,publicNative8:false,additionalPhysicalDevices:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,images:attachments.length}));
