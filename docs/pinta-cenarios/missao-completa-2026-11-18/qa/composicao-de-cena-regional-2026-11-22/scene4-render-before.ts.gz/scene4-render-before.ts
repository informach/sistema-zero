import { createCanvas } from '@napi-rs/canvas'
import { readPintaRegionScene } from '../packages/core/src/studio/pinta-region-scene'
import { scene4Fixture } from '../packages/core/tests/fixtures/pinta-region-scene'
import { drawScene } from '../packages/pinta/src/export/sceneDrawing'
const scene=readPintaRegionScene(JSON.stringify(scene4Fixture()))
if(!scene) throw Error('Invalid positive control')
const atlas=createCanvas(128,128), canvas=createCanvas(64,64)
try {
  drawScene(canvas.getContext('2d'),scene,new Map(scene.tilesets.map(sheet=>[sheet.id,atlas])),'back')
  throw Error('Expected unsupported regional renderer')
} catch(error){
  if(!(error instanceof TypeError)||!String(error).includes('forEach'))throw error
  console.log(JSON.stringify({privateContract:4,unsupportedRenderReproduced:true,error:String(error)}))
}
