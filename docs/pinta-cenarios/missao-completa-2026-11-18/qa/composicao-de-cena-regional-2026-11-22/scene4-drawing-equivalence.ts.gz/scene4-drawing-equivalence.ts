import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { createCanvas } from '@napi-rs/canvas'
import { vilaEFloresta } from '../packages/pinta/scripts/homologacao/fixture'
import { isObjectLayer } from '../packages/pinta/src/core/project'
import { exportPintaScene } from '../packages/pinta/src/export/scene'
import { drawScene } from '../packages/pinta/src/export/sceneDrawing'
const baseline='5a9c8cfe2'
const prior=execFileSync('git',['show',`${baseline}:packages/pinta/src/export/sceneDrawing.ts`],{encoding:'utf8'})
mkdirSync('packages/pinta/.cache',{recursive:true})
writeFileSync('packages/pinta/.cache/scene-drawing-before-regions.ts',prior.replace(/from '(\.[^']+)'/g,(_,path)=>`from '${resolve('packages/pinta/src/export',path).replaceAll('\\','/')}'`))
const old=await import('../packages/pinta/.cache/scene-drawing-before-regions.ts')
const transpiler=new Bun.Transpiler({loader:'ts'})
const before=transpiler.transformSync(execFileSync('git',['show',`${baseline}:packages/core/src/studio/pinta-scene-runtime.ts`],{encoding:'utf8'}))
const after=transpiler.transformSync(readFileSync('packages/core/src/studio/pinta-scene-runtime.ts','utf8'))
if(before!==after)throw Error('Type-only Core change altered JavaScript')
const digest=createHash('sha256');let comparisons=0
for(const rotation of [0,90,180,270])for(const flipX of [false,true])for(const flipY of [false,true]){
  const {map,assets}=vilaEFloresta()
  const instance=map.layers.flatMap(layer=>isObjectLayer(layer)?layer.objects:[]).find(object=>object.setId)!
  instance.rotation=rotation;instance.flipX=flipX?true:undefined;instance.flipY=flipY?true:undefined
  const scene=await exportPintaScene(map,id=>assets.find(asset=>asset.id===id)??null,async()=> 'png')
  const images=new Map()
  for(const item of [...scene.tilesets.map(sheet=>({id:sheet.id,width:sheet.columns*16,height:Math.ceil(sheet.count/sheet.columns)*16})),...(scene.art??[])]){
    const image=createCanvas(item.width,item.height),brush=image.getContext('2d')
    for(let y=0;y<item.height;y+=3)for(let x=0;x<item.width;x+=3){brush.fillStyle=`rgba(${(x*13+y*7)%256},${(x*3+y*17)%256},${(x*7+y*11)%256},${((x+y)%4+1)/4})`;brush.fillRect(x,y,3,3)}
    images.set(item.id,image)
  }
  for(const time of [0,125,450])for(const pass of ['back','front'] as const){
    const frames=[old.drawScene,drawScene].map(draw=>{const canvas=createCanvas(128,96),ctx=canvas.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.scale(.25,.25);draw(ctx,scene,images,pass,time,{x:7.25,y:-2.5});return Buffer.from(ctx.getImageData(0,0,128,96).data)})
    if(!frames[0]!.equals(frames[1]!))throw Error('Historical pixels changed')
    digest.update(frames[1]!);comparisons++
  }
}
const result={baseline,comparisons,legacyRgbaIdentical:true,coreEmittedJavaScriptIdentical:true,coreEmittedSha256:createHash('sha256').update(after).digest('hex'),rgbaSha256:digest.digest('hex')}
writeFileSync('.cache/scene4-drawing-equivalence.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
