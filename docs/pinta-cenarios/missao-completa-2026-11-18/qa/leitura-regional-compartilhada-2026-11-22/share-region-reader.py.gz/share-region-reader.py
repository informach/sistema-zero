from pathlib import Path
import subprocess

root = Path.cwd()
pinta_path = root / 'packages/pinta/src/tiles/regionCells.ts'
core_path = root / 'packages/core/src/creations/pinta-region-reader.ts'
source = pinta_path.read_text(encoding='utf-8')
baseline = subprocess.check_output(['git', 'show', '446aea7c0:packages/pinta/src/tiles/regionCells.ts']).decode('utf-8')
if source != baseline or core_path.exists():
    raise RuntimeError('Unexpected source or existing destination; preserve concurrent work')
start = source.index('\nfunction readChunkCell(')
end = source.index('/** Atomic admission, last edit wins, one clone per changed chunk. */')
reader = source[start:end]
header = """/** Queries on boundary-admitted immutable region grids. No document writer is activated here. */
import { PINTA_REGION_SIDE, type PintaRegionBounds, type PintaRegionCells } from './pinta-regions'

type RegionChunk = PintaRegionCells['chunks'][number]
const EMPTY_CELL = -1
/** Memory-index key only, independent of account/storage authority keys. */
export const regionChunkKey = (col: number, row: number) => `${col},${row}`
export const compareRegionChunks = (a: RegionChunk, b: RegionChunk) => a.row - b.row || a.col - b.col
export const indexRegionChunks = (grid: PintaRegionCells) =>
  new Map(grid.chunks.map((chunk) => [regionChunkKey(chunk.col, chunk.row), chunk]))

const keyOf = regionChunkKey
const order = compareRegionChunks
const indexOf = indexRegionChunks
"""
updated = source[:start] + '\n' + source[end:]
removed = [
    'const keyOf = (col: number, row: number) => `${col},${row}`\n',
    'const order = (a: RegionChunk, b: RegionChunk) => a.row - b.row || a.col - b.col\n',
    'const indexOf = (grid: PintaRegionCells) =>\n  new Map(grid.chunks.map((chunk) => [keyOf(chunk.col, chunk.row), chunk]))\n',
]
for part in removed:
    if updated.count(part) != 1:
        raise RuntimeError('Unexpected query helper')
    updated = updated.replace(part, '')
updated = updated.replace('  PINTA_REGION_SIDE,\n', '''  PINTA_REGION_SIDE,
  compareRegionChunks as order,
  createRegionCellReader,
  indexRegionChunks as indexOf,
  regionCellAt,
  regionChunkKey as keyOf,
''', 1)
updated = updated.replace("import { EMPTY_CELL, isValidCell } from './cell'\n", "import { EMPTY_CELL, isValidCell } from './cell'\n\nexport { createRegionCellReader, regionCellAt }\n", 1)
with core_path.open('x', encoding='utf-8', newline='\n') as output:
    output.write(header + reader)
pinta_path.write_text(updated, encoding='utf-8', newline='\n')
print('Moved existing query implementation; editor mutation helpers delegate to the same memory index')
