import { readPintaRegionScene } from '../packages/core/src/studio/pinta-region-scene'
import { PintaSceneSchema } from '../packages/core/src/studio/pinta-scene'
import { sceneObjects, sceneSolidAt, sceneSpawn } from '../packages/core/src/studio/pinta-scene-runtime'
import { sceneIntersectsBox } from '../packages/core/src/studio/pinta-scene-geometry'
import { scene4BudgetFixture } from '../packages/core/tests/fixtures/pinta-region-scene'
import { encodePintaRegionLayers } from '../packages/core/src/creations/pinta-regions'
import {writeFileSync} from 'node:fs'
const source=scene4BudgetFixture(1,1),s=readPintaRegionScene(JSON.stringify(source))
if(!s)throw Error('Missing admitted private scene')
const dense=PintaSceneSchema.parse({version:1,id:'dense',name:'Dense',tileSize:16,cols:1,rows:1,tilesets:source.tilesets,layers:[{id:'floor',kind:'tiles',name:'Floor',visible:true,tilesetId:'ground',cells:[0]}]})
if(!sceneSolidAt(dense,8,8)||!sceneIntersectsBox(dense,{x:1,y:1,width:4,height:4}))throw Error('Legacy positive controls failed')
const cells=new Int16Array(1024).fill(-1);cells[0]=0
const wire=encodePintaRegionLayers([{kind:'regions',version:1,side:32,chunks:[{col:-1,row:-1,cells}]}],{col:-32,row:-32,cols:1,rows:1})![0]!
const objects=readPintaRegionScene(JSON.stringify({...source,layers:[{id:'objects',kind:'objects',name:'Objects',visible:true,objects:[{id:'instance',name:'Instance',type:'',shape:'set',setId:'set',x:0,y:0,width:16,height:16,properties:{}}]}],sets:[{id:'set',cols:1,rows:1,origin:{col:-32,row:-32},layers:[{id:'floor',kind:'tiles',name:'Floor',visible:true,tilesetId:'ground',cells:wire},{id:'markers',kind:'objects',name:'Markers',visible:true,objects:[{id:'child',name:'Child',type:'',shape:'point',x:-512,y:-512,width:0,height:0,properties:{}}]}]}]}))
if(!objects)throw Error('Missing admitted set fixture')
const result={privateScene4Only:true,legacyControlsPass:true,cases:[
  {name:'occupied cell at world origin',actual:sceneSolidAt(s,8,8),expected:true},
  {name:'empty signed cell inside the world',actual:sceneSolidAt(s,-8,-8),expected:false},
  {name:'body over occupied regional tile',actual:sceneIntersectsBox(s,{x:1,y:1,width:4,height:4}),expected:true},
  {name:'default spawn respects signed world origin',actual:sceneSpawn(s),expected:{x:-1016,y:-1016}},
  {name:'set children use the definition origin',actual:sceneObjects(objects).find(o=>o.id==='instance/child')?.x,expected:0},
]}
const mismatches=result.cases.filter(c=>JSON.stringify(c.actual)!==JSON.stringify(c.expected)).length
if(mismatches!==5)throw Error('Unexpected unsupported-query baseline: '+mismatches)
writeFileSync('.cache/region-game-queries-before.json',JSON.stringify({...result,mismatches},null,2));console.log(JSON.stringify({...result,mismatches}))
