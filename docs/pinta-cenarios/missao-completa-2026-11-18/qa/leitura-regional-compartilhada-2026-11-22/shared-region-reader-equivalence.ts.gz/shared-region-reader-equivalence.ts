import { execFileSync } from 'node:child_process'
import { mkdirSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { resolve } from 'node:path'
import * as shared from '../packages/core/src/creations/pinta-region-reader'
import * as editor from '../packages/pinta/src/tiles/regionCells'
import type { PintaRegionCells } from '../packages/core/src/creations/pinta-regions'
const baseline='446aea7c0'
const source=execFileSync('git',['show',baseline+':packages/pinta/src/tiles/regionCells.ts'],{encoding:'utf8'})
mkdirSync('packages/pinta/.cache',{recursive:true})
writeFileSync('packages/pinta/.cache/region-reader-before-core.ts',source.replace(/from '(\.[^']+)'/g,(_,path)=>`from '${resolve('packages/pinta/src/tiles',path).replaceAll('\\','/')}'`))
const old=await import('../packages/pinta/.cache/region-reader-before-core.ts')
let cases=0,pointQueries=0;const digest=createHash('sha256')
for(let seed=0;seed<32;seed++){
  const grid:PintaRegionCells={kind:'regions',version:1,side:32,chunks:[]}
  for(let row=-2;row<=2;row++)for(let col=-2;col<=2;col++){
    const cells=Int16Array.from({length:1024},(_,i)=>(i+row+col+seed)%5===0?-1:((i+seed)%8)*4096+(i+seed)%16)
    grid.chunks.push({row,col,cells})
  }
  const readers=[old.createRegionCellReader(grid),shared.createRegionCellReader(grid),editor.createRegionCellReader(grid)]
  for(let i=0;i<512;i++){
    const col=(i*17+seed*7)%176-80,row=(i*31+seed*11)%176-80
    const expected=old.regionCellAt(grid,col,row)
    if(shared.regionCellAt(grid,col,row)!==expected||editor.regionCellAt(grid,col,row)!==expected||readers.some(reader=>reader.at(col,row)!==expected))throw Error('Point changed')
    digest.update(String(expected)+',');pointQueries++
  }
  for(let rectIndex=0;rectIndex<8;rectIndex++)for(const order of [undefined,'row-major'] as const){
    const rect={col:seed-70+rectIndex*5,row:seed-50-rectIndex*3,cols:17+rectIndex*7,rows:9+rectIndex*5}
    const visits=readers.map(reader=>{const result:number[]=[];reader.visitOccupied(rect,(cell:number,col:number,row:number)=>result.push(cell,col,row),order);return JSON.stringify(result)})
    if(visits[0]!==visits[1]||visits[0]!==visits[2])throw Error('Visitation/order changed')
    digest.update(visits[0]!);cases++
  }
}
const result={baseline,cases,pointQueries,exactLegacyVisitsAndFlags:true,editorAndCoreUseSameFunctions:editor.createRegionCellReader===shared.createRegionCellReader&&editor.regionCellAt===shared.regionCellAt,sha256:digest.digest('hex')}
if(!result.editorAndCoreUseSameFunctions)throw Error('Duplicate query implementation')
writeFileSync('.cache/shared-region-reader-equivalence.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
