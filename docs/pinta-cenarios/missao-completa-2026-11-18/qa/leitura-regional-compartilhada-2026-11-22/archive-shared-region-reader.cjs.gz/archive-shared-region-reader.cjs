const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const baseline='446aea7c0',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/leitura-regional-compartilhada-2026-11-22/';
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex'),read=name=>fs.readFileSync('.cache/shared-region-reader-'+name+'.log','utf8');
for(const [name,count]of [['pinta-full',2748],['core-full',3227],['focused',34]]){const text=read(name);if(!text.includes(count+' pass')||!text.includes('0 fail')||/[1-9]\d* skip/.test(text))throw Error(name+' incomplete');}
for(const name of ['core-types','pinta-types','studio-types','diff'])if(read(name).trim())throw Error(name+' not clean');
if(!read('biome').includes('Checked 4 files'))throw Error('Lint missing');
const old=JSON.parse(fs.readFileSync('.cache/shared-region-reader-equivalence.json'));if(old.cases!==512||old.pointQueries!==16384||!old.exactLegacyVisitsAndFlags||!old.editorAndCoreUseSameFunctions)throw Error('Equivalence missing');
const rows=suites=>suites.flatMap(s=>[...(s.specs||[]).flatMap(s=>s.tests),...rows(s.suites||[])]);
const reports=[['packages/studio/.cache/pinta-physical-regions-results/report.json',61,'physical-report.json'],['packages/studio/.cache/pinta-integration-results/report.json',12,'integration-report.json']];
for(const [file,expected]of reports){const report=JSON.parse(fs.readFileSync(file));if(report.stats.expected!==expected||report.stats.unexpected||report.stats.skipped||report.stats.flaky||rows(report.suites).some(test=>test.results.length!==1||test.results[0].status!=='passed'))throw Error('Browser failed '+file);}
fs.mkdirSync(out,{recursive:true});const records=[];
function add(raw,name){const bytes=zlib.gzipSync(raw),file=name+'.gz';fs.writeFileSync(out+file,bytes,{flag:'wx'});records.push({file,bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)});}
for(const name of ['focused','core-focused','pinta-full','core-full','core-types','pinta-types','studio-types','biome','browser','integration-browser','diff'])add(Buffer.from(read(name)),name+'.log');
for(const [file,,name]of reports)add(fs.readFileSync(file),name);
for(const name of ['shared-region-reader-equivalence.ts','shared-region-reader-equivalence.json','shared-region-reader-equivalence.log','share-region-reader.py','region-game-queries-before.ts','region-game-queries-before.json','region-game-queries-before.log','archive-shared-region-reader.cjs'])add(fs.readFileSync('.cache/'+name),name);
const files=[...new Set([...cp.execFileSync('git',['diff','--name-only','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n')].filter(Boolean))];
const sources=files.map(file=>({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline+':'+file]).status===0?{previousSha256:sha(cp.execFileSync('git',['show',baseline+':'+file]))}:{})}));
const count=text=>({pass:Number(text.match(/(\d+) pass/)?.[1]),fail:0,skipped:0,assertions:Number(text.match(/(\d+) expect\(\) calls/)?.[1]),files:Number(text.match(/across (\d+) files/)?.[1])});
fs.writeFileSync(out+'index.json',JSON.stringify({baseline,records,sources,pinta:count(read('pinta-full')),core:count(read('core-full')),focused:count(read('focused')),legacyQueries:old,browser:{pass:73,physical:61,integration:12,retries:0},editorReexportsSameFunctions:true,duplicateProductReader:false,newIo:false,publicNative8:false,gameplayRuntime4:false,worldLoader5:false,additionalPhysicalDevices:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,browser:73}));
