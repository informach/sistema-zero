import assert from 'node:assert/strict'
import { metadataBudgetFixture } from '../packages/pinta/scripts/homologacao/metadataBudget'
import type { PintaMemoryAsset } from '../packages/pinta/src/core/assetMemory'
import { isObjectLayer, type RegionTilemapAsset } from '../packages/pinta/src/core/project'
import { encodeRegionGalleryBackup } from '../packages/pinta/src/export/regionBackup'
import { createEditorStore } from '../packages/pinta/src/state/editorStore'

const { source } = metadataBudgetFixture()
const escaped: RegionTilemapAsset = { ...source, layers: source.layers.map(layer => !isObjectLayer(layer) ? layer : { ...layer, objects: layer.objects.map(object => ({ ...object, properties: Object.fromEntries(Object.entries(object.properties).map(([key, value]) => [key, typeof value === 'string' ? '\0'.repeat(value.length) : value])) })) }) }
let writes = 0, hostCalls = 0
const editor = createEditorStore<PintaMemoryAsset>({ asset: source, persist: async () => { writes++ }, acceptEdit: () => { hostCalls++; return true } })
const accepted = editor.getState().commit(escaped)
const beforeFlush = { accepted, dirty: editor.getState().dirty, canUndo: editor.getState().canUndo, unchanged: editor.getState().asset === source, hostCalls }
await editor.getState().flush()
console.log(JSON.stringify({ beforeFlush, writes, backupRefused: encodeRegionGalleryBackup([escaped]) === null }))
assert.equal(accepted, false, 'JSON acima do teto não pode entrar no histórico/autosave')
