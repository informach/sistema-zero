import {execFileSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
import {createTilemapAsset,effectiveLayer,isObjectLayer,isTileLayer} from '../packages/pinta/src/core/project'
import {createMapSet,placeMapSet,detachMapSet} from '../packages/pinta/src/tiles/sets'
const baseline=execFileSync('git',['show','9a4b06828:packages/pinta/src/tiles/sets.ts'],{encoding:'utf8'}).replaceAll("from '../core/","from '../packages/pinta/src/core/").replaceAll("from './","from '../packages/pinta/src/tiles/")
writeFileSync('.cache/pinta-set-parallax-baseline.ts',baseline,{flag:'wx'})
const original=await import('./pinta-set-parallax-baseline.ts')
const base=createTilemapAsset({name:'Fonte',tilesetId:'ground',cols:2,rows:2})
base.layers=[{id:'group',kind:'group',name:'Longe',visible:true,parallaxX:.5,parallaxY:.25},...base.layers.map(l=>({...l,parentId:'group'}))]
const set=createMapSet(base,{col:0,row:0,cols:2,rows:2},16,'Longe'),target=createTilemapAsset({name:'Destino',tilesetId:'ground',cols:4,rows:4})
target.layers.push({id:'sets',kind:'objects',name:'Conjuntos',visible:true,parallaxX:.8,parallaxY:2,objects:[]})
const placed=placeMapSet(target,'sets',set,0,0,16),id=placed.layers.find(isObjectLayer)!.objects[0]!.id
const read=(result:typeof target)=>{const l=result.layers.filter(isTileLayer).find(l=>l.id!==target.layers[0]!.id)!;const e=effectiveLayer(result,l);return{x:e.parallaxX,y:e.parallaxY}}
const before=read(original.detachMapSet(placed,'sets',id,set,16)),after=read(detachMapSet(placed,'sets',id,set,16))
assert.deepEqual(before,{x:1,y:1});assert.deepEqual(after,{x:.4,y:.5})
const report={baseline:'9a4b06828',before,after,expected:{x:.4,y:.5},realRegressionReproduced:true}
writeFileSync('.cache/pinta-set-parallax-regression.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(report))
