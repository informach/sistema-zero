import {execFileSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {createRequire} from 'node:module'
const ts=createRequire(new URL('../packages/studio/package.json',import.meta.url))('typescript')
const file='packages/members/tests/db/creations.repository.test.ts',baseline='9a3e3eb4a',incoming='6a3028a8d353cf9eb0ae948f4ae5f718f40f2726'
const git=ref=>execFileSync('git',['show',ref+':'+file],{encoding:'utf8'})
const before=git(baseline),remote=git(incoming),merged=execFileSync('git',['show',':'+file],{encoding:'utf8'})
function tests(text){
  const tree=ts.createSourceFile('creations.repository.test.ts',text,ts.ScriptTarget.Latest,true),found=new Map()
  function root(node){return ts.isIdentifier(node)?node.text==='test':ts.isCallExpression(node)?root(node.expression):ts.isPropertyAccessExpression(node)?root(node.expression):false}
  function visit(node){if(ts.isExpressionStatement(node)&&ts.isCallExpression(node.expression)&&root(node.expression.expression)){
    const call=node.expression,name=call.arguments[0]
    if(name&&(ts.isStringLiteral(name)||ts.isNoSubstitutionTemplateLiteral(name))){if(found.has(name.text))throw Error('Duplicate named SQL test');found.set(name.text,node.getText(tree))}
  }ts.forEachChild(node,visit)}visit(tree);return found
}
const previousTests=tests(before),incomingTests=tests(remote),mergedTests=tests(merged)
for(const [name,body]of previousTests)if(mergedTests.get(name)!==body)throw Error('Existing test changed: '+name)
const replaced=new Map([
 ['delete confere capacidade contra formato confirmado e pendente sob lock','delete confere capacidade contra formato %s confirmado e pendente sob lock'],
 ['delete espera uma atualização concorrente e reavalia a versão, sem preflight externo','delete reavalia formato %s após atualização concorrente sob lock'],
])
let preserved=0
for(const [name,body]of incomingTests){if(replaced.has(name)){if(!mergedTests.has(replaced.get(name)))throw Error('Format-6 parameterization missing');continue}if(mergedTests.get(name)!==body)throw Error('Incoming test changed: '+name);preserved++}
const hash=text=>createHash('sha256').update(text).digest('hex')
const result={baseline,incoming,file,previousTests:previousTests.size,incomingTests:incomingTests.size,mergedTests:mergedTests.size,previousBodiesIntact:true,incomingBodiesIntact:preserved,existingFormat6ParameterizedReplacements:replaced.size,sha256:{before:hash(before),incoming:hash(remote),merged:hash(merged)}}
writeFileSync('.cache/staging-6a-test-union.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
