import {createTilemapAsset,createTilesetAsset,sanitizePintaAsset,sanitizeRegionTilemapAsset,withPintaSchemaStamp} from '../packages/pinta/src/core/project'
import {cloneObjectsWithResources} from '../packages/pinta/src/core/mapClone'
import {createRegionMapObject,addMapObjects} from '../packages/pinta/src/tiles/mapObjects'
import {prepareMapRegions,expandRegionMap} from '../packages/pinta/src/tiles/regionMap'
import {DEFAULT_OBJECT_SCATTER,scatterMapObjects} from '../packages/pinta/src/tiles/objectScatter'
const p=prepareMapRegions(createTilemapAsset({name:'mundo',tilesetId:'ground',cols:2,rows:2}));if(!p.ok)throw Error();const e=expandRegionMap(p.map,{col:-100,row:-100,cols:10000,rows:10000});if(!e.ok)throw Error();
const art=createTilesetAsset({name:'arte',tileSize:16}),a=withPintaSchemaStamp({...art,id:'direct',tileProperties:{'0':{target:{type:'object' as const,value:'tree'}}}}),b=withPintaSchemaStamp({...art,id:'dependent',tileProperties:{'0':{linked:{type:'asset' as const,value:'direct'}}}}),resources=[{sourceId:'art-a',capturedAt:1,asset:a},{sourceId:'art-b',capturedAt:1,asset:b}],map={...e.map,layers:[...e.map.layers,{id:'objects',kind:'objects' as const,name:'Objetos',visible:true,objects:[]}],resources},tree=createRegionMapObject({id:'tree',name:'Árvore',shape:'art',art:{assetId:'dependent',tile:0},x:-.25,y:-.5,width:16.5,height:24.25,rotation:45,properties:{self:{type:'object',value:'tree'}}})!;
const result=scatterMapObjects(map,'objects',tree,16,[{col:-4,row:-3},{col:-1,row:-1}],{...DEFAULT_OBJECT_SCATTER,density:1,spacing:0},'stroke');
const graph=cloneObjectsWithResources([tree],resources,()=> 'stroke:960096:0',(_id,i)=>`stroke:960096:resource:${i}`);
const candidate={...addMapObjects(map,'objects',graph.objects),resources:[...resources,...graph.resources]};
console.log(JSON.stringify({reason:result.reason,count:result.addedIds.length,sourceValid:!!sanitizeRegionTilemapAsset(map),candidateValid:!!sanitizeRegionTilemapAsset(candidate),graph:graph.resources.map(r=>({id:r.asset.id,schema:r.asset.schema,parsed:sanitizePintaAsset(r.asset)}))},(_k,v)=>v instanceof Uint8Array?`Uint8Array(${v.length})`:v,2));
