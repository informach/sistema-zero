import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {readFileSync,writeFileSync} from 'node:fs'
import {dirname,resolve} from 'node:path'
import {isDeepStrictEqual} from 'node:util'
import {pathToFileURL} from 'node:url'
import {createTilemapAsset} from '../packages/pinta/src/core/project'
import {createMapObject} from '../packages/pinta/src/tiles/mapObjects'
import {DEFAULT_OBJECT_SCATTER,scatterMapObjects} from '../packages/pinta/src/tiles/objectScatter'
import {addObjectLayer} from '../packages/pinta/src/tiles/tilemapOps'
const revision='06b442e57',file='packages/pinta/src/tiles/objectScatter.ts',source=execFileSync('git',['show',`${revision}:${file}`]),sha=(v:Uint8Array|string)=>createHash('sha256').update(v).digest('hex'),baseline=resolve('.cache/legacy-object-scatter-06b.ts');
const rewritten=source.toString().replace(/from '([^']+)'/g,(_m,specifier)=>`from ${JSON.stringify(resolve(dirname(resolve(file)),specifier).replaceAll('\\','/'))}`)
writeFileSync(baseline,rewritten,{flag:'wx'})
const old=(await import(pathToFileURL(baseline).href)).scatterMapObjects as typeof scatterMapObjects,
 cases=[]
for(const density of [0,.35,1])for(const spacing of [0,2])for(const rotate of [false,true])for(const mirror of [false,true])for(const fractionalOffset of [false,true]){
 const base=addObjectLayer(createTilemapAsset({name:'legado',tilesetId:'ground',cols:16,rows:12}),'Objetos'),layerId=base.layers.at(-1)!.id,map={...base,layers:base.layers.map(l=>l.id===layerId?{...l,offsetX:fractionalOffset?8.5:0,offsetY:fractionalOffset?-.25:0}:l)},object=createMapObject({id:'source',name:'Árvore',shape:'art',art:{assetId:'tree'},x:32,y:16,width:24,height:16,rotation:45,properties:{self:{type:'object',value:'source'}}}),positions=Array.from({length:192},(_,i)=>({col:i%16,row:Math.floor(i/16)})),settings={...DEFAULT_OBJECT_SCATTER,density,spacing,rotate,mirror,seed:37},args=[map,layerId,object,16,positions,settings,'stroke'] as const,a=old(...args),b=scatterMapObjects(...args)
 if(!isDeepStrictEqual(a.map,b.map)||!isDeepStrictEqual(a.addedIds,b.addedIds)||a.overflow!==b.overflow)throw Error(`Legacy mismatch ${JSON.stringify(settings)} ${fractionalOffset}`)
 cases.push({density,spacing,rotate,mirror,fractionalOffset,objects:b.addedIds.length,documentSha256:sha(JSON.stringify(b.map))})
}
console.log(JSON.stringify({revision,file,baselineSha256:sha(source),currentSha256:sha(readFileSync(file)),scope:'Dense maps without private object references; that intentional fix is covered separately',cases,matched:cases.length,failed:0},null,2))
