const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const baseline='72d0ad34f',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/captura-e-transporte-regional-2026-11-22/';
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const full=fs.readFileSync('.cache/region-capture-full.log','utf8');
if(!full.includes('2728 pass')||!full.includes('0 fail')||/[1-9]\d* skip/.test(full))throw Error('Suíte incompleta');
if(!fs.readFileSync('.cache/region-capture-red.log','utf8').includes('2 fail'))throw Error('Reproduções ausentes');
if(!fs.readFileSync('.cache/region-capture-focused.log','utf8').includes('50 pass'))throw Error('Focados incompletos');
for(const kind of ['pinta','studio'])if(fs.readFileSync('.cache/region-capture-'+kind+'-types.log','utf8').trim())throw Error('Tipos incompletos');
if(!fs.readFileSync('.cache/region-capture-biome.log','utf8').includes('Checked 13 files')||fs.readFileSync('.cache/region-capture-diff.log','utf8').trim())throw Error('Lint/diff incompletos');
const rows=suites=>suites.flatMap(s=>[...(s.specs||[]).flatMap(s=>s.tests),...rows(s.suites||[])]);
const reports=[['packages/studio/.cache/pinta-physical-regions-results/report.json',51,'persistence-report.json'],['packages/studio/.cache/pinta-integration-results/report.json',12,'pinta-studio-report.json']];
const attachments=[];
for(const [file,expected]of reports){
  const report=JSON.parse(fs.readFileSync(file));
  if(report.stats.expected!==expected||report.stats.unexpected||report.stats.skipped||report.stats.flaky||rows(report.suites).some(t=>t.results.length!==1||t.results[0].status!=='passed'))throw Error('Navegador incompleto: '+file);
  for(const test of rows(report.suites))for(const attachment of test.results[0].attachments||[])if(attachment.name==='vila-regional.pinta.json')attachments.push(attachment);
}
if(attachments.length!==2)throw Error('Pacotes regionais ausentes');
fs.mkdirSync(out,{recursive:true});
const records=[];
function addBytes(raw,name){const bytes=zlib.gzipSync(raw),file=out+name+'.gz';if(fs.existsSync(file)){if(!fs.readFileSync(file).equals(bytes))throw Error('Recibo existente divergente: '+file);}else fs.writeFileSync(file,bytes,{flag:'wx'});records.push({file:name+'.gz',bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)});}
function add(file,name){addBytes(fs.readFileSync(file),name);}
for(const name of ['fixture-failures','fixture-failures-second','red','focused-first','focused','browser-focused','browser','integration-browser','full','pinta-types-first','fixture-types','pinta-types','studio-types','biome-first','biome','diff'])add('.cache/region-capture-'+name+'.log',name+'.log');
for(const [file,,name]of reports)add(file,name);
for(const [index,attachment]of attachments.entries()){
  const raw=attachment.path?fs.readFileSync(attachment.path):Buffer.from(attachment.body,'base64');
  const doc=JSON.parse(raw.toString('utf8'));
  if(doc.version!==8||doc.assets.length!==6||!doc.assets.some(asset=>asset.kind==='tilemap'&&asset.layers.length===18&&asset.cols===10000&&asset.rows===10000&&asset.origin.col===-64&&asset.origin.row===-64))throw Error('Artefato regional inesperado');
  addBytes(raw,'vila-regional-'+index+'.pinta.json');
}
add('.cache/archive-region-capture.cjs','archive-region-capture.cjs');
add('.cache/region-capture-emission.ts','region-capture-emission.ts');
add('.cache/region-capture-emission.json','emission.json');
add('.cache/region-capture-format-final.log','format-final.log');
const files=[...new Set([...cp.execFileSync('git',['diff','--name-only','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n')].filter(Boolean))];
const sources=files.map(file=>({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline+':'+file]).status===0?{previousSha256:sha(cp.execFileSync('git',['show',baseline+':'+file]))}:{})}));
fs.writeFileSync(out+'index.json',JSON.stringify({baseline,records,sources,suite:{pass:2728,fail:0,skipped:0,assertions:Number(full.match(/(\d+) expect\(\) calls/)?.[1]),files:252},focused:{pass:50,assertions:195,files:7},browser:{pass:63,retries:0,persistence:51,integration:12,regionalCaptureNew:4,profiles:['desktop','cpu-4x']},nativeRoundTrip:{assets:6,tileLayers:16,totalLayers:18,logicalCellsPerMap:100000000,origin:{col:-64,row:-64},independentRealm:true,byteIdentical:true,artifacts:2},opaqueCapture:{refused:true,futureChunkReads:0,transactions:1},publicNative8:false,scene4:false,cloud7:false,partialCloudInventory:false,additionalDevices:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,pass:2728,browser:63,artifacts:attachments.length}));
