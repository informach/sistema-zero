import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
const compiler = new Bun.Transpiler({ loader: 'ts', target: 'browser' })
const sha = (text: string) => createHash('sha256').update(text).digest('hex')
const files = ['packages/pinta/src/core/localAssetOrigin.ts', 'packages/pinta/src/core/mapResourceVersions.ts']
const result = files.map(file => {
  const previous = compiler.transformSync(execFileSync('git', ['show', `72d0ad34f:${file}`], {encoding:'utf8'}))
  const current = compiler.transformSync(readFileSync(file,'utf8'))
  if (previous !== current) throw Error('JavaScript alterado: '+file)
  return {file,previous:sha(previous),current:sha(current),identical:true}
})
writeFileSync('.cache/region-capture-emission.json', JSON.stringify(result,null,2))
console.log(JSON.stringify({identicalModules:result.length}))
