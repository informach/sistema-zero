const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/integracao-staging-f5b1ceca8-2026-11-21/',records=[],sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=(...args)=>cp.execFileSync('git',args,{encoding:'utf8',maxBuffer:32*1024*1024}).trimEnd();
const ours=git('rev-parse','HEAD'),upstream=git('rev-parse','MERGE_HEAD');
if(ours!=='dffe8608329d0b1038ec2e05f97fd82cb0132699'||upstream!=='f5b1ceca8e542580f6285bcd0a95ae1310c600af'||git('diff','--name-only','--diff-filter=U'))throw Error('Candidato de merge divergente');
const suite=fs.readFileSync('.cache/integracao-f5-pinta-suite.log','utf8'),boundary=fs.readFileSync('.cache/integracao-f5-fronteiras.log','utf8');
if(!suite.includes('2641 pass')||!suite.includes('0 fail')||/\n\s+\d+ skip\r?\n/.test(suite)||!boundary.includes('184 pass')||!boundary.includes('0 fail'))throw Error('Testes incompletos');
for(const name of ['pinta-types','studio-types','3d-exato','diff'])if(fs.readFileSync('.cache/integracao-f5-'+name+'.log','utf8').trim())throw Error('Verificação incompleta: '+name);
if(!fs.readFileSync('.cache/integracao-f5-biome.log','utf8').includes('Checked 13 files'))throw Error('Lint incompleto');
function rows(suites){return suites.flatMap(s=>[...(s.specs||[]).flatMap(spec=>spec.tests),...rows(s.suites||[])])}
const reports=[['packages/studio/.cache/pinta-integration-results/report.json',12],['packages/studio/.cache/pinta-scenes-results/report.json',10]];
for(const [file,count]of reports){const r=JSON.parse(fs.readFileSync(file));if(r.stats.expected!==count||r.stats.unexpected||r.stats.flaky||r.stats.skipped||rows(r.suites).some(t=>t.results.length!==1||t.results[0].status!=='passed'))throw Error('Navegador incompleto: '+file)}
const runtime=JSON.parse(fs.readFileSync('.cache/integracao-f5-runtime.json')),python=JSON.parse(fs.readFileSync('.cache/integracao-f5-python.json'));
if(runtime.results.length!==4||runtime.results.some(v=>v.chars>(v.scene?(v.target==='g2d'?397000:437000):(v.target==='g2d'?369500:415000)))||python.pygame!=='2.5.8'||python.videoDriver!=='dummy')throw Error('Runtime/ambiente divergente');
const origin=new Map(git('ls-tree','-r','-z','--full-tree',upstream).split('\0').filter(Boolean).map(line=>{const tab=line.indexOf('\t');return[line.slice(tab+1),line.slice(0,tab).split(' ')[2]]}));
const staged=new Map(git('ls-files','--stage','-z').split('\0').filter(Boolean).map(line=>{const tab=line.indexOf('\t'),fields=line.slice(0,tab).split(' ');if(fields[2]!=='0')throw Error('Índice não resolvido');return[line.slice(tab+1),fields[1]]}));
const incoming=git('diff','--name-only','-z','HEAD...MERGE_HEAD').split('\0').filter(Boolean).map(file=>({file,upstreamGitBlob:origin.get(file)??null,mergedGitBlob:staged.get(file)??null}));
if(incoming.length!==222||incoming.some(v=>v.upstreamGitBlob!==v.mergedGitBlob))throw Error('Conteúdo remoto não conservado');
if(git('diff','--cached','--name-only','--','packages/pinta'))throw Error('Pinta autoral mudou nesta integração');
const testedSourceTree=git('write-tree');
fs.mkdirSync(out,{recursive:true});
function add(file,name){const raw=fs.readFileSync(file),bytes=zlib.gzipSync(raw),target=name+'.gz';fs.writeFileSync(out+target,bytes,{flag:'wx'});records.push({file:target,bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)})}
for(const name of ['pinta-suite','fronteiras','pinta-types','studio-types','browser','phaser','3d-exato','diff','biome'])add('.cache/integracao-f5-'+name+'.log',name+'.log');
add('.cache/integracao-f5-runtime.json','runtime.json');add('.cache/integracao-f5-python.json','python.json');
for(const [i,[file]]of reports.entries())add(file,'playwright-'+i+'-report.json');
add('.cache/archive-integration-f5.cjs','archive-integration-f5.cjs');
const selected=['packages/core/src/studio/pinta-scene-player.ts','packages/studio/src/official-extensions/map-2d/bootstrap.ts','packages/studio/src/official-extensions/map-2d/runtime.test.ts','packages/studio/src/official-extensions/map-2d/__tests__/hostVariant.test.ts','packages/studio/src/official-extensions/runtimeSource.ts','packages/studio/src/official-extensions/runtimeSource.test.ts','packages/studio/src/official-extensions/runtimePayloadBudget.test.ts','packages/studio/src/official-extensions/game-2d/runtime/worldGroups.ts','packages/studio/src/official-extensions/game-2d/__tests__/limitWarnings.test.ts','packages/studio/src/official-extensions/game-2d/__tests__/bundle.test.ts','packages/studio/src/official-extensions/game-2d-advanced/runtime/shell.ts','packages/studio/src/official-extensions/game-2d-advanced/runtime/visualEffects.ts','packages/studio/src/testing/contracts/contracts.test.ts'];
fs.writeFileSync(out+'index.json',JSON.stringify({parents:{ours,upstream,ancestor:git('merge-base',ours,upstream)},testedSourceTree,records,sources:selected.map(file=>({file,sha256:sha(fs.readFileSync(file))})),incoming,browserTests:22,pintaTests:2641,optionalNativeControlsExecuted:3,boundaryTests:184,python,runtimeSizes:runtime.results.map(({compileMs,...v})=>v),publicNative8:false,physicalIO3:false,authenticatedRollout:false},null,2));
console.log(JSON.stringify({records:records.length,sources:selected.length,incoming:incoming.length,testedSourceTree,remoteContentsConserved:true}));
