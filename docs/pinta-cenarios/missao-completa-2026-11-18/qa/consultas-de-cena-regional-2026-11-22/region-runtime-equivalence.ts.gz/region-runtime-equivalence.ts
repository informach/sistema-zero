import {execFileSync} from 'node:child_process'
import {mkdirSync,writeFileSync} from 'node:fs'
import {resolve,basename} from 'node:path'
import {createHash} from 'node:crypto'
import * as runtime from '../packages/core/src/studio/pinta-scene-runtime'
import * as geometry from '../packages/core/src/studio/pinta-scene-geometry'
import {sceneObjectTransformSource} from '../packages/core/src/studio/pinta-scene-transform.generated'
import {vilaEFloresta} from '../packages/pinta/scripts/homologacao/fixture'
import {exportPintaScene} from '../packages/pinta/src/export/scene'
import {isObjectLayer} from '../packages/pinta/src/core/project'
const baseline='b29f25237',files=['pinta-scene-runtime.ts','pinta-scene-geometry.ts','pinta-scene-transform.generated.ts'],folder='packages/core/.cache/region-runtime-baseline'
mkdirSync(folder,{recursive:true})
for(const name of files){const source=execFileSync('git',['show',baseline+':packages/core/src/studio/'+name],{encoding:'utf8'});writeFileSync(folder+'/'+name,source.replace(/from '(\.[^']+)'/g,(_,path)=>{const target=basename(path)+'.ts';return "from '"+resolve(files.includes(target)?folder:'packages/core/src/studio',path).replaceAll('\\','/')+"'";}))}
const oldRuntime=await import('../'+folder+'/pinta-scene-runtime.ts'),oldGeometry=await import('../'+folder+'/pinta-scene-geometry.ts'),oldSource=await import('../'+folder+'/pinta-scene-transform.generated.ts')
const portable=(source:string)=>new Function(source+';return {sceneIntersectsBox,sceneMoveBox,scenePlatformLanding};')()
const oldPortable=portable(oldSource.sceneObjectTransformSource),newPortable=portable(sceneObjectTransformSource),digest=createHash('sha256');let comparisons=0,scenes=0
function equal(old:unknown,current:unknown,label:string){const a=JSON.stringify(old),b=JSON.stringify(current);if(a!==b)throw Error('Legacy changed: '+label+' '+a+' / '+b);digest.update(a+'\n');comparisons++}
for(let seed=0;seed<32;seed++){
 const {map,assets,cabana}=vilaEFloresta(),instance=map.layers.flatMap(l=>isObjectLayer(l)?l.objects:[]).find(o=>o.setId)!
 instance.rotation=[0,37,90,180][seed%4];instance.flipX=seed&4?true:undefined;instance.flipY=seed&8?true:undefined
 if(seed&16){const shape=map.layers.flatMap(l=>isObjectLayer(l)?l.objects:[]).find(o=>o.role==='danger')!;shape.collision=true}
 for(const native of [map,cabana]){
  const scene=await exportPintaScene(native,id=>assets.find(a=>a.id===id)??null,async()=> 'png');scenes++
  equal(oldRuntime.sceneObjects(scene),runtime.sceneObjects(scene),'objects');equal(oldRuntime.sceneSpawn(scene),runtime.sceneSpawn(scene),'spawn')
  for(let i=0;i<64;i++){
   const x=((i*37+seed*11)%(scene.cols*16+64))-32,y=((i*23+seed*17)%(scene.rows*16+64))-32,box={x:x+.25,y:y-.5,width:8,height:12}
   equal(oldRuntime.sceneSolidAt(scene,x,y),runtime.sceneSolidAt(scene,x,y),'point')
   const expected=oldGeometry.sceneIntersectsBox(scene,box);equal(expected,geometry.sceneIntersectsBox(scene,box),'body');equal(expected,newPortable.sceneIntersectsBox(scene,box),'portable body');equal(expected,oldPortable.sceneIntersectsBox(scene,box),'old portable body')
   if(i%8===0){const desired={...box,y:box.y+35};equal(oldGeometry.scenePlatformLanding(scene,box,desired,seed&1?-1:1),geometry.scenePlatformLanding(scene,box,desired,seed&1?-1:1),'landing');equal(oldGeometry.sceneMoveBox(scene,box,17,-23),geometry.sceneMoveBox(scene,box,17,-23),'motion');equal(oldPortable.sceneMoveBox(scene,box,17,-23),newPortable.sceneMoveBox(scene,box,17,-23),'portable motion');equal(oldRuntime.moveSceneCharacter(scene,{x,y},8,4),runtime.moveSceneCharacter(scene,{x,y},8,4),'point motion')}
  }
 }
}
const result={baseline,scenes,comparisons,legacyQueryJsonIdentical:true,portableGeometryIdentical:true,previousSourceChars:oldSource.sceneObjectTransformSource.length,currentSourceChars:sceneObjectTransformSource.length,sha256:digest.digest('hex')}
writeFileSync('.cache/region-runtime-equivalence.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
