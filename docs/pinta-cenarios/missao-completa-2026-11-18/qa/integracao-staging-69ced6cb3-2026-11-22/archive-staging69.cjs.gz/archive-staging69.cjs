const fs = require('node:fs'), cp = require('node:child_process'), crypto = require('node:crypto'), zlib = require('node:zlib');
const baseline = '68121986166388d42b0f931296644862631bad29', incoming = '69ced6cb3ed9ae3ac2a4b09db68361cb20068b5a';
const out = 'docs/pinta-cenarios/missao-completa-2026-11-18/qa/integracao-staging-69ced6cb3-2026-11-22/';
const git = args => cp.execFileSync('git', args, { encoding: 'utf8' }).trim();
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const files = git(['diff', '--cached', '--name-only']).split('\n').filter(Boolean);
if (files.length !== 16 || files.some(file => !file.startsWith('packages/studio/') && !file.startsWith('docs/'))) throw Error('Escopo recebido inesperado');
const identity = files.map(file => ({file, index: git(['rev-parse', ':' + file]), incoming: git(['rev-parse', incoming + ':' + file])}));
if (identity.some(row => row.index !== row.incoming)) throw Error('Conteúdo remoto alterado');
if (git(['diff', '--cached', '--name-only', baseline, '--', 'packages/pinta', 'packages/core', 'packages/molda-cenarios'])) throw Error('Fonte fora da integração alterada');
const reports = [
  ['packages/studio/.cache/pinta-integration-results/report.json', 12, 'pinta-studio-report.json'],
  ['packages/studio/.cache/staging69-bridge-report.json', 4, 'bridge-reload-report.json'],
];
for (const [file, expected] of reports) {
  const report = JSON.parse(fs.readFileSync(file));
  const rows = suites => suites.flatMap(s => [...(s.specs || []).flatMap(s => s.tests), ...rows(s.suites || [])]);
  if (report.stats.expected !== expected || report.stats.unexpected || report.stats.skipped || report.stats.flaky || rows(report.suites).some(t => t.results.length !== 1 || t.results[0].status !== 'passed')) throw Error('Navegador incompleto: ' + file);
}
for (const kind of ['pinta', 'studio']) if (fs.readFileSync('.cache/staging69-' + kind + '-types.log', 'utf8').trim()) throw Error('Tipos incompletos');
const focused = fs.readFileSync('.cache/staging69-studio-focused.log', 'utf8');
if (!focused.includes('89 pass') || !focused.includes('0 fail')) throw Error('Focados incompletos');
if (!fs.readFileSync('.cache/staging69-biome.log', 'utf8').includes('Checked 11 files') || fs.readFileSync('.cache/staging69-diff.log', 'utf8').trim()) throw Error('Lint/diff incompletos');
fs.mkdirSync(out, {recursive:true});
const records = [];
function add(file, name) {
  const raw = fs.readFileSync(file), bytes = zlib.gzipSync(raw);
  fs.writeFileSync(out + name + '.gz', bytes, {flag:'wx'});
  records.push({file:name + '.gz', bytes:bytes.length, sha256:sha(bytes), rawBytes:raw.length, rawSha256:sha(raw)});
}
for (const name of ['studio-focused','integration-browser','bridge-browser','pinta-types','studio-types','biome','diff']) add('.cache/staging69-' + name + '.log', name + '.log');
for (const [file,,name] of reports) add(file,name);
add('.cache/archive-staging69.cjs','archive-staging69.cjs');
fs.writeFileSync(out + 'index.json', JSON.stringify({baseline,incoming,identity,records,focused:{pass:89,assertions:348,files:3},browser:{pass:16,retries:0,profiles:['chromium-desktop'],integration:12,bridgeAndReload:4},carriedPintaSuite:{head:baseline,pass:2713,files:249,unchangedSources:true},publicNative8:false,deploy:false,physicalDevicesAdditional:false},null,2));
console.log(JSON.stringify({preserved:identity.length,records:records.length,browser:16,focused:89}));
