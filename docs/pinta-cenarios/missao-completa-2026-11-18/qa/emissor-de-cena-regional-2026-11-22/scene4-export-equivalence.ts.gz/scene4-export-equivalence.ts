import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { exportPintaScene } from '../packages/pinta/src/export/scene'
import { createTilemapAsset, createTilesetAsset, type PintaAsset } from '../packages/pinta/src/core/project'
import { createMapObject } from '../packages/pinta/src/tiles/mapObjects'
import { vilaEFloresta } from '../packages/pinta/scripts/homologacao/fixture'
const baseline = 'f3466d1b6'
const original = execFileSync('git', ['show', `${baseline}:packages/pinta/src/export/scene.ts`], { encoding: 'utf8' })
const rewritten = original.replace(/from '(\.[^']+)'/g, (_, path) => `from '${resolve('packages/pinta/src/export', path).replaceAll('\\', '/')}'`)
mkdirSync('packages/pinta/.cache', { recursive: true })
writeFileSync('packages/pinta/.cache/scene-before-regional-writer.ts', rewritten)
const previous = await import('../packages/pinta/.cache/scene-before-regional-writer.ts')
const digest = createHash('sha256')
let cases = 0
const versions = new Set<number>()
async function compare(map: Parameters<typeof exportPintaScene>[0], assets: PintaAsset[], expected?: number) {
  const find = (id: string) => assets.find(asset => asset.id === id) ?? null
  const image = async (asset: PintaAsset) => `data:image/png;base64,${asset.id}`
  const old = await previous.exportPintaScene(map, find, image)
  const current = await exportPintaScene(map, find, image)
  if (expected && current.version !== expected) throw Error('Wrong positive version')
  const text = JSON.stringify(current)
  if (text !== JSON.stringify(old)) throw Error(`Legacy export changed in ${cases}`)
  digest.update(text); cases++; versions.add(current.version)
}
for (let version = 1; version <= 3; version++) for (let seed = 0; seed < 32; seed++) {
  const sheet = { ...createTilesetAsset({name:'Terra',tileSize:16,now:0}), id:'ground' }
  const map = {...createTilemapAsset({name:'Mapa',tilesetId:sheet.id,cols:8,rows:8,now:0}), id:'map'}
  const first = map.layers[0]!
  if (!('cells' in first)) throw Error('No cells')
  for (let i=0;i<first.cells.length;i++) first.cells[i] = (i + seed) % 3 ? -1 : (seed % 8) * 4096
  first.id='floor'; first.front=!!(seed%2); first.opacity=(seed%4+1)/4
  if(version === 2) map.resources=[{sourceId:'source',capturedAt:0,asset:sheet}]
  if(version === 3) map.physics='precise'
  map.layers.push({id:'objects',kind:'objects',name:'Marcas',visible:true,objects:[
    {...createMapObject({x:seed+0.25,y:4.5,role:'spawn',properties:{life:{type:'int',value:seed}}}),id:'spawn'}
  ]})
  await compare(map,[sheet],version)
}
const vila=vilaEFloresta()
await compare(vila.map,vila.assets)
await compare(vila.cabana,vila.assets)
if(versions.size!==3) throw Error('Missing version controls')
const result={baseline,cases,versions:[...versions],serializedExportsIdentical:true,sha256:digest.digest('hex')}
writeFileSync('.cache/scene4-export-equivalence.json',JSON.stringify(result,null,2))
console.log(JSON.stringify(result))
