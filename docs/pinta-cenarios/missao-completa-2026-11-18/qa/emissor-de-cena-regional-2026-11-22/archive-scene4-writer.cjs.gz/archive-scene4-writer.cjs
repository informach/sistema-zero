const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const baseline='f3466d1b6',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/emissor-de-cena-regional-2026-11-22/';
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const records=[];
function addBytes(raw,name){const bytes=zlib.gzipSync(raw),file=out+name+'.gz';if(fs.existsSync(file)){if(!fs.readFileSync(file).equals(bytes))throw Error('Existing receipt differs '+file);}else fs.writeFileSync(file,bytes,{flag:'wx'});records.push({file:name+'.gz',bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)});}
const read=name=>fs.readFileSync('.cache/scene4-writer-'+name+'.log','utf8');
for(const [name,count]of [['pinta-full',2738],['core-full',3215],['focused',30]]){const log=read(name);if(!log.includes(count+' pass')||!log.includes('0 fail')||/[1-9]\d* skip/.test(log))throw Error(name+' incomplete');}
for(const name of ['core-types','pinta-types','studio-types','diff'])if(read(name).trim())throw Error(name+' not clean');
if(!read('biome').includes('Checked 8 files'))throw Error('Lint missing');
const rows=suites=>suites.flatMap(s=>[...(s.specs||[]).flatMap(s=>s.tests),...rows(s.suites||[])]);
const reports=[['packages/studio/.cache/pinta-physical-regions-results/report.json',57,'physical-report.json'],['packages/studio/.cache/pinta-integration-results/report.json',12,'integration-report.json']];
let artifacts=0;
for(const [file,expected,name]of reports){const report=JSON.parse(fs.readFileSync(file));if(report.stats.expected!==expected||report.stats.unexpected||report.stats.skipped||report.stats.flaky||rows(report.suites).some(t=>t.results.length!==1||t.results[0].status!=='passed'))throw Error('Browser incomplete '+file);addBytes(fs.readFileSync(file),name);for(const test of rows(report.suites))for(const a of test.results[0].attachments||[])if(a.name==='vila-scene4.json'){const raw=a.path?fs.readFileSync(a.path):Buffer.from(a.body,'base64');const doc=JSON.parse(raw.toString('utf8'));if(doc.version!==4||doc.layers.length!==18||doc.tilesets.length!==2||doc.sets.length!==1||doc.physics!=='legacy')throw Error('Bad scene artifact');addBytes(raw,'vila-scene4-'+artifacts+++'.json');}}
if(artifacts!==2)throw Error('Missing real Vila');
for(const name of ['focused','pinta-full','core-full','browser-focused','browser','integration-browser','core-types','pinta-types','studio-types','biome','diff'])addBytes(Buffer.from(read(name)),name+'.log');
for(const name of ['scene4-export-equivalence.ts','scene4-export-equivalence.json','scene4-export-equivalence.log','archive-scene4-writer.cjs'])addBytes(fs.readFileSync('.cache/'+name),name);
const files=[...new Set([...cp.execFileSync('git',['diff','--name-only','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n')].filter(Boolean))];
const sources=files.map(file=>({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline+':'+file]).status===0?{previousSha256:sha(cp.execFileSync('git',['show',baseline+':'+file]))}:{})}));
const count=log=>({pass:Number(log.match(/(\d+) pass/)?.[1]),fail:0,skipped:0,assertions:Number(log.match(/(\d+) expect\(\) calls/)?.[1]),files:Number(log.match(/across (\d+) files/)?.[1])});
fs.writeFileSync(out+'index.json',JSON.stringify({baseline,records,sources,pinta:count(read('pinta-full')),core:count(read('core-full')),focused:count(read('focused')),browser:{pass:69,physical:57,integration:12,retries:0,realVilaArtifacts:artifacts,profiles:['desktop','cpu-4x']},legacyExport:{cases:98,versions:[1,2,3],exactJson:true},publicScene4:false,png5:false,regionalRuntime:false,publicNative8:false,cloud7:false,additionalPhysicalDevices:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,artifacts}));
