import {ZStream,zlibInflateInit2,zlibInflate,zlibInflateEnd,Z_OK,Z_STREAM_END,Z_NO_FLUSH} from '../packages/molda/node_modules/pako'
import {zlibSync,gzipSync} from '../packages/pinta/node_modules/fflate'
import {writeFileSync} from 'node:fs'
function read(bytes:Uint8Array,limit:number){
 const stream=new ZStream(),decoder=new TextDecoder('utf-8',{fatal:true}),parts:string[]=[];let total=0,largestOutput=0
 if(zlibInflateInit2(stream,15)!==Z_OK)throw Error('initialization failed')
 stream.input=bytes;stream.next_in=0;stream.avail_in=bytes.length
 try{
  while(true){
   const output=new Uint8Array(Math.min(16384,limit-total+1));largestOutput=Math.max(largestOutput,output.length)
   stream.output=output;stream.next_out=0;stream.avail_out=output.length
   const before=stream.total_in,status=zlibInflate(stream,Z_NO_FLUSH),used=stream.next_out
   total+=used;if(total>limit)throw Error('over-budget')
   if(status!==Z_OK&&status!==Z_STREAM_END)throw Error('invalid stream '+status)
   parts.push(decoder.decode(output.subarray(0,used),{stream:true}))
   if(status===Z_STREAM_END){if(stream.avail_in||stream.total_in!==bytes.length)throw Error('trailing input');parts.push(decoder.decode());return{accepted:true,total,largestOutput,text:parts.join('')}}
   if(before===stream.total_in&&!used)throw Error('incomplete stream')
  }
 }catch(error){return{accepted:false,total,largestOutput,error:String(error)}}finally{if(zlibInflateEnd(stream)!==Z_OK)throw Error('cleanup failed')}
}
const plain=new TextEncoder().encode('Pinta 🌳\n'.repeat(20000)),compressed=zlibSync(plain),bad=compressed.slice();bad[bad.length-1]^=1
const tail=new Uint8Array(compressed.length+1);tail.set(compressed)
const forgedTail=new Uint8Array(compressed.length+4);forgedTail.set(compressed);forgedTail.set(compressed.subarray(-4),compressed.length)
const concat=new Uint8Array(compressed.length*2);concat.set(compressed);concat.set(compressed,compressed.length)
const entries={valid:compressed,badChecksum:bad,trailing:tail,forgedTail,concatenated:concat,truncated:compressed.subarray(0,-1),gzip:gzipSync(plain)}
const results=Object.fromEntries(Object.entries(entries).map(([name,bytes])=>{const r=read(bytes,plain.length);return[name,{...r,...('text'in r?{text:undefined,exactText:r.text===new TextDecoder().decode(plain)}:{})}]}))
const result={runtime:Bun.version,plainBytes:plain.length,compressedBytes:compressed.length,results,budget:read(compressed,128)}
if(!results.valid?.accepted||Object.entries(results).some(([name,r])=>name!=='valid'&&r.accepted)||result.budget.accepted)throw Error('Decoder probe failed')
writeFileSync('.cache/probe-pako-zlib.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
