import {zlibSync} from '../packages/pinta/node_modules/fflate'
import {writeFileSync} from 'node:fs'
const plain=new TextEncoder().encode('Pinta 🌳\n'.repeat(20000)),compressed=zlibSync(plain)
async function read(bytes:Uint8Array,limit:number){
 let position=0,total=0,maxChunk=0
 const input=new ReadableStream<Uint8Array>({pull(controller){if(position>=bytes.length){controller.close();return}const end=Math.min(bytes.length,position+1024);controller.enqueue(bytes.subarray(position,end));position=end}})
 const reader=input.pipeThrough(new DecompressionStream('deflate')).getReader()
 try{while(true){const next=await reader.read();if(next.done)break;total+=next.value.byteLength;maxChunk=Math.max(maxChunk,next.value.byteLength);if(total>limit)throw Error('over-budget')}return{accepted:true,total,maxChunk}}catch(error){try{await reader.cancel(error)}catch{}return{accepted:false,total,maxChunk,error:String(error)}}
}
const bad=compressed.slice();bad[bad.length-1]^=1
const trailing=new Uint8Array(compressed.length+1);trailing.set(compressed)
const results={runtime:Bun.version,plainBytes:plain.length,compressedBytes:compressed.length,valid:await read(compressed,plain.length),badChecksum:await read(bad,plain.length),trailing:await read(trailing,plain.length),budget:await read(compressed,128)}
writeFileSync('.cache/probe-deflate-stream.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results))
