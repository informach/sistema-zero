const fs = require('node:fs'), cp = require('node:child_process'), crypto = require('node:crypto'), zlib = require('node:zlib');
const baseline = '505c0a21a0912368f8d280a3d0238cbb6e7ece96';
const out = 'docs/pinta-cenarios/missao-completa-2026-11-18/qa/recuperacao-de-formatos-futuros-2026-11-21/';
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const suite = fs.readFileSync('.cache/future-recovery-full.log', 'utf8');
if (!suite.includes('2688 pass') || !suite.includes('0 fail') || /[1-9]\d* skip/.test(suite)) throw Error('Suíte incompleta');
if (!fs.readFileSync('.cache/future-recovery-red.log', 'utf8').includes('2 fail')) throw Error('Reprodução ausente');
for (const kind of ['pinta', 'studio']) if (fs.readFileSync(`.cache/future-recovery-${kind}-types.log`, 'utf8').trim()) throw Error('Tipos incompletos');
const reports = [
  ['packages/studio/.cache/pinta-future-recovery-results/report.json', 3],
  ['packages/studio/.cache/pinta-authority-results/report.json', 7],
  ['packages/studio/.cache/pinta-local-chunks-results/report.json', 14],
];
const tests = suites => suites.flatMap(s => [...(s.specs || []).flatMap(s => s.tests), ...tests(s.suites || [])]);
for (const [file, count] of reports) {
  const report = JSON.parse(fs.readFileSync(file));
  if (report.stats.expected !== count || report.stats.unexpected || report.stats.skipped || report.stats.flaky || tests(report.suites).some(t => t.results.length !== 1 || t.results[0].status !== 'passed')) throw Error('Navegador incompleto: ' + file);
}
fs.mkdirSync(out, { recursive: true });
const records = [];
function add(file, name) {
  const raw = fs.readFileSync(file), bytes = zlib.gzipSync(raw), target = name + '.gz';
  fs.writeFileSync(out + target, bytes, { flag: 'wx' });
  records.push({ file: target, bytes: bytes.length, sha256: sha(bytes), rawBytes: raw.length, rawSha256: sha(raw) });
}
for (const name of ['red', 'focused-first', 'focused', 'full', 'pinta-types', 'studio-types', 'browser', 'authority-browser', 'chunks-browser', 'biome', 'diff']) add('.cache/future-recovery-' + name + '.log', 'future-recovery-' + name + '.log');
for (const [index, [file]] of reports.entries()) add(file, 'playwright-' + index + '-report.json');
add('.cache/archive-future-recovery.cjs', 'archive-future-recovery.cjs');
const sources = [...new Set([
  ...cp.execFileSync('git', ['diff', '--name-only', '--', '*.ts', '*.tsx'], { encoding: 'utf8' }).trim().split('\n'),
  ...cp.execFileSync('git', ['ls-files', '--others', '--exclude-standard', '--', '*.ts', '*.tsx'], { encoding: 'utf8' }).trim().split('\n'),
].filter(Boolean))].map(file => ({ file, sha256: sha(fs.readFileSync(file)), ...(cp.spawnSync('git', ['cat-file', '-e', baseline + ':' + file]).status === 0 ? { previousSha256: sha(cp.execFileSync('git', ['show', baseline + ':' + file])) } : {}) }));
fs.writeFileSync(out + 'index.json', JSON.stringify({ baseline, records, sources, suite: { passed: 2688, failed: 0, skipped: 0, assertions: 35164, files: 247 }, browser: { passed: 24, retries: 0, profiles: ['desktop', 'cpu-4x (chunks only)'], realIndexedDB: true }, scope: 'patched local readers with a complete transaction inventory; opaque future envelopes simulated', publicNative8: false, physicalIO3: false, cloudPartialInventory: false, stagingRollout: false }, null, 2));
console.log(JSON.stringify({ records: records.length, sources: sources.length, passed: 2688, browser: 24 }));
