import { resolve } from 'node:path'
import base from '../packages/studio/playwright.pinta-render.config'
const root=resolve(import.meta.dirname,'..'),port=5524,outputDir=resolve(root,'.cache/pinta-render-opacity-browser-r2')
export default {...base,testDir:resolve(root,'packages/studio/e2e'),outputDir,reporter:[['list'],['json',{outputFile:resolve(outputDir,'report.json')}]],use:{...base.use,baseURL:'http://127.0.0.1:5524'},webServer:{command:'bun scripts/serve-map-budget-e2e.ts',cwd:resolve(root,'packages/pinta'),env:{PINTA_BUDGET_PORT:String(port),PINTA_RENDER_PROOF:'1'},url:'http://127.0.0.1:5524',reuseExistingServer:false,timeout:120000}}




