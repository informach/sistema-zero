const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const target='2bb89391871b90cd200ed44334397bbf1d822639',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/integracao-staging-2bb893918-2026-11-22/';
const git=(...args)=>cp.execFileSync('git',args,{encoding:'utf8'}).trim();
if(git('rev-parse','MERGE_HEAD')!==target)throw Error('Unexpected incoming head');
const files=git('diff','--cached','--name-only').split('\n');
const incoming=files.filter(file=>!file.startsWith(out)&&file!=='docs/superpowers/plans/2026-11-21-pinta-missao-retomada.md');
if(incoming.length!==39)throw Error('Unexpected incoming count');
const fixture='packages/studio/src/state/fixtures/projectStorageBrowser.ts';
const blobs=incoming.map(file=>{const received=git('rev-parse',target+':'+file),index=git('rev-parse',':'+file);if(received!==index&&file!==fixture)throw Error('Incoming modified '+file);return{file,received,index,identical:received===index,...(file===fixture?{qaCorrection:'Narrow unknown name/tree fields before inspecting raw recovery records'}:{})};});
if(blobs.some(b=>b.file.startsWith('packages/pinta/')||b.file.startsWith('packages/core/')||b.file.startsWith('packages/molda')))throw Error('Unexpected scope');
const read=name=>fs.readFileSync('.cache/staging-2bb-'+name+'.log','utf8');
for(const [name,count]of [['studio-focused',34],['member-shell-focused',23],['admin-focused',2]])if(!read(name).includes(count+' pass')||!read(name).includes('0 fail'))throw Error(name+' incomplete');
if(!read('studio-focused').includes('Studio.cases.tsx: 25 pass, 0 fail'))throw Error('Isolated Studio missing');
if(read('studio-types').trim())throw Error('Studio types failed');
if(!read('studio-types-first').includes('TS2322')||!read('storage-browser').includes('1 pass')||!read('storage-browser').includes('0 fail'))throw Error('Fixture proof incomplete');
if(!read('biome').includes('Checked 18 files')||!read('reload-browser').includes('2 passed')||!read('integration-browser').includes('12 passed'))throw Error('Checks incomplete');
const report=JSON.parse(fs.readFileSync('packages/studio/.cache/pinta-integration-results/report.json'));if(report.stats.expected!==12||report.stats.unexpected||report.stats.skipped||report.stats.flaky)throw Error('Integration failed');
fs.mkdirSync(out,{recursive:true});const records=[];
for(const name of ['studio-focused','member-shell-focused','admin-focused','studio-types-first','studio-types','biome','fixture-biome','reload-browser','integration-browser','storage-browser']){const raw=Buffer.from(read(name)),bytes=zlib.gzipSync(raw),file=name+'.log.gz';fs.writeFileSync(out+file,bytes,{flag:'wx'});records.push({file,sha256:crypto.createHash('sha256').update(bytes).digest('hex')});}
for(const [source,file]of [['packages/studio/.cache/mission/storage-driver-chromium-normal.txt','storage-driver.txt.gz'],['.cache/archive-staging-2bb.cjs','archive.cjs.gz']]){const bytes=zlib.gzipSync(fs.readFileSync(source));fs.writeFileSync(out+file,bytes,{flag:'wx'});records.push({file,sha256:crypto.createHash('sha256').update(bytes).digest('hex')});}
fs.writeFileSync(out+'index.json',JSON.stringify({target,blobs,records,pintaCoreUnchanged:true,pintaSuiteCarried:{commit:'7f30bf123',pass:2738},studio:{pass:34,isolatedChildPass:25,assertions:96,isolatedAssertions:161},memberShell:{pass:23,assertions:38},admin:{pass:2,assertions:15},browser:{pass:14,retries:0,integration:12,reloadHidden:2},lint:{errors:0,warnings:2,info:1,source:'incoming lesson generator, preserved'},sqlTestsRun:false,featureMergedIntoStaging:false},null,2));
console.log(JSON.stringify({incoming:blobs.length,records:records.length,browser:14}));
