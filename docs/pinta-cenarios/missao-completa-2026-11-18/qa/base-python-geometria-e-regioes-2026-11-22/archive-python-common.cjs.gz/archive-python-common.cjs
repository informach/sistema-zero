const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { gzipSync } = require('node:zlib');
const root = path.resolve(__dirname, '..');
const target = path.join(root, 'docs/pinta-cenarios/missao-completa-2026-11-18/qa/base-python-geometria-e-regioes-2026-11-22');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const entries = [
  ['pinta-full.log', '.cache/pinta-python-common-full-final.log'],
  ['focused.log', '.cache/pinta-python-common-focused.log'],
  ['pinta-types.log', '.cache/pinta-python-common-types.log'],
  ['core-types.log', '.cache/pinta-python-common-core-types.log'],
  ['studio-types.log', '.cache/pinta-python-common-studio-types.log'],
  ['biome.log', '.cache/pinta-python-common-lint.log'],
  ['delivered-python.json', '.cache/pinta-python-common-output.json'],
  ['environment.json', '.cache/pinta-python-common-environment.json'],
  ['python-generated.log', '.cache/pinta-python-common-generated.log'],
  ['js-generated.log', '.cache/pinta-python-common-js-generated.log'],
  ['diff.log', '.cache/pinta-python-common-diff.log'],
  ['first-full.log', '.cache/pinta-python-common-full.log'],
  ['query-before.log', '.cache/pinta-python-region-query-before.log'],
  ['browser.log', '.cache/pinta-python-common-browser.log'],
  ['integration-browser.log', '.cache/pinta-python-common-integration.log'],
  ['physical-report.json', 'packages/studio/.cache/pinta-physical-regions-results/report.json'],
  ['integration-report.json', 'packages/studio/.cache/pinta-integration-results/report.json'],
  ['archive-python-common.cjs', '.cache/archive-pinta-python-common.cjs'],
];
const records = entries.map(([name, source]) => {
  const raw = fs.readFileSync(path.join(root, source));
  const zipped = gzipSync(raw);
  const file = name + '.gz';
  fs.writeFileSync(path.join(target, file), zipped);
  return { file, bytes: zipped.length, sha256: sha(zipped), rawSha256: sha(raw) };
});
const sources = [
  'packages/pinta/src/export/pygameProject.ts',
  'packages/pinta/src/export/pythonSceneGeometry.ts',
  'packages/pinta/src/export/pythonSceneGeometry.test.ts',
  'packages/pinta/src/export/pythonSceneRegions.ts',
  'packages/pinta/src/export/pythonSceneRegions.test.ts',
  'packages/pinta/src/tiles/cellAccess.test.ts',
].map(file => { const raw = fs.readFileSync(path.join(root, file)); return { file, bytes: raw.length, sha256: sha(raw) }; });
for (const [name, source, count] of [
  ['regions', 'packages/studio/.cache/pinta-physical-regions-results/report.json', 67],
  ['integration', 'packages/studio/.cache/pinta-integration-results/report.json', 12],
]) {
  const report = JSON.parse(fs.readFileSync(path.join(root, source), 'utf8'));
  if (report.stats.expected !== count || report.stats.unexpected !== 0 || report.stats.flaky !== 0 || report.stats.skipped !== 0) throw Error('Unexpected browser outcome: '+ name);
}
fs.writeFileSync(path.join(target, 'index.json'), JSON.stringify({ baseline: '18458d850be9f0c0678e6b39bd2c376d4dbc06a4', records, sources }, null, 2) + '\n');
console.log(JSON.stringify({ records: records.length, sources: sources.length }));
