module.exports=async function(qa){
 const assert=require('node:assert/strict'),fs=require('node:fs'),c=qa.canaryRollback,p=c.page;
 assert.equal(new URL(p.url()).origin,c.origin);assert.equal(new URL(p.url()).pathname,'/login');
 const lines=fs.readFileSync('C:/Users/tocha/superadmin-sistemazero-STAGING.txt','utf8').replace(/^\uFEFF/,'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
 assert.equal(lines.length,2);assert(lines[0].includes('@'));
 await p.locator('#email').fill(lines[0]);await p.locator('#password').fill(lines[1]);lines.fill('');
 await p.getByRole('button',{name:'Entrar',exact:true}).click();
 await p.waitForURL(u=>u.pathname!=='/login',{timeout:30000});
 await p.goto(c.origin+'/pinta',{waitUntil:'domcontentloaded',timeout:45000});
 await p.getByRole('button',{name:'Abrir qa-vila-floresta-20261120 (Mapa)',exact:true}).click({timeout:25000});
 await p.getByRole('img',{name:'Grade do mapa',exact:true}).waitFor({state:'visible',timeout:20000});
 await require('./prepare-offline-reader.cjs')(c.shadow);
 const native=await require('./checkpoint-owned-vila.cjs')(c.shadow);assert.deepEqual(native.assets,qa.retowIndependentB.native.assets);
 c.nativeBaseline=native;c.phase='b1-open';
 return{phase:c.phase,authenticated:true,native,independentStorage:true,realPublishedFrontend:true,physicalDevices:1,credentialsKeptInMemory:true,events:c.events};
};
