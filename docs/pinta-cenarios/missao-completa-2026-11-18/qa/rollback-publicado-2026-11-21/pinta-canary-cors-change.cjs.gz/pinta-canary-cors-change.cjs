const fs=require('node:fs'),cp=require('node:child_process'),assert=require('node:assert/strict');
const mode=process.argv[2];assert(['add','remove'].includes(mode));
const prefix='.cache/pinta-canary-cors-'+mode;assert(!fs.existsSync(prefix+'-start.json'),'Inspect receipt before retrying');
const name='pinta-qa-rollback-20261121',origin='https://pinta-qa-rollback-20261121-staging.up.railway.app';
const readPrefix=prefix+'-fresh';cp.execFileSync('node',['.cache/pinta-canary-cors-read.mjs',readPrefix],{stdio:'ignore',windowsHide:true});
const current=JSON.parse(fs.readFileSync(readPrefix+'.json','utf8'));
let proposed;
if(mode==='add'){
 assert.deepEqual(current,JSON.parse(fs.readFileSync('.cache/pinta-canary-cors-before.json','utf8')));
 assert(!current.rules.some(r=>r.id===name));
 const standard=current.rules.find(r=>r.id==='dev-and-staging');assert(standard.allowed.methods.includes('GET')&&standard.allowed.methods.includes('PUT'));
 const own={...structuredClone(standard),id:name,allowed:{...standard.allowed,origins:[origin]},maxAgeSeconds:60};
 proposed={...current,rules:[...current.rules,own]};
}else{
 const previous=JSON.parse(fs.readFileSync('.cache/pinta-canary-cors-add-proposed.json','utf8')),own=previous.rules.find(r=>r.id===name);
 assert.deepEqual(current.rules.find(r=>r.id===name),own);proposed={...current,rules:current.rules.filter(r=>r.id!==name)};
}
fs.writeFileSync(prefix+'-proposed.json',JSON.stringify(proposed,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(prefix+'-start.json',JSON.stringify({at:new Date().toISOString(),mode,bucket:'testes-ugc',temporaryOrigin:origin,mutationOutcome:'unknown'},null,2)+'\n',{flag:'wx'});
const log=fs.openSync(prefix+'-wrangler.log','wx');const r=cp.spawnSync('C:/Users/tocha/.bun/bin/bun.exe',['--no-env-file','x','--no-install','wrangler','r2','bucket','cors','set','testes-ugc','--file',prefix+'-proposed.json','--force'],{windowsHide:true,env:{...process.env,CLOUDFLARE_ACCOUNT_ID:'bcc0f2d44140e05b69152cba326132f8'},stdio:['ignore',log,log]});fs.closeSync(log);
assert.equal(r.status,0,'Do not retry: verify provider state');cp.execFileSync('node',['.cache/pinta-canary-cors-read.mjs',prefix+'-verified'],{stdio:'ignore',windowsHide:true});assert.deepEqual(JSON.parse(fs.readFileSync(prefix+'-verified.json','utf8')),proposed);
fs.writeFileSync(prefix+'-result.json',JSON.stringify({at:new Date().toISOString(),mode,bucket:'testes-ugc',temporaryOrigin:origin,verified:true,preservedOtherRules:true},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({mode,verified:true,bucket:'testes-ugc',preservedOtherRules:true}));
