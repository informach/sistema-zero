import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFileSync,writeFileSync} from 'node:fs'
import {assetFromJson} from '../packages/pinta/src/export/assetJson'
const id='fa6cd481-d157-4849-8ea1-f871aedce0e1'
const text=readFileSync('C:/Users/tocha/projects/sistema-zero-pinta-retomada-20261119/.cache/pinta-canary-final-native/'+id+'.pinta.json','utf8')
const parsed=assetFromJson(text);assert(parsed.asset?.kind==='tilemap');assert.equal(parsed.asset.id,id);assert.deepEqual(parsed.warnings,[])
function canonical(value:unknown):unknown{if(ArrayBuffer.isView(value))return Array.from(value as unknown as ArrayLike<number>);if(Array.isArray(value))return value.map(canonical);if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().filter(k=>(value as Record<string,unknown>)[k]!==undefined).map(k=>[k,canonical((value as Record<string,unknown>)[k])]));return value}
const sha256=createHash('sha256').update(JSON.stringify(canonical(parsed.asset))).digest('hex');assert.equal(sha256,'15c3393cbbc9861df0c80036e98130bcb5ebe545369a77347fb58cf149b6e296')
const result={at:new Date().toISOString(),id,nativeSha256:sha256,fullNativeEqual:true,warnings:parsed.warnings,publicNativeParser:true,actualAuthenticatedR2Download:true,revision:4,cloudFormat:6}
writeFileSync('.cache/pinta-canary-final-native-parsed.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result))
