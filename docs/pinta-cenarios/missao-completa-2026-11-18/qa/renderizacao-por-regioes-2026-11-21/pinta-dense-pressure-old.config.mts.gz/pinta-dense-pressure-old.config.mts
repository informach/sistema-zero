import {resolve} from 'node:path'
import base from '../packages/studio/playwright.pinta-render.config'
const root=resolve(import.meta.dirname,'..'),port=5517,outputDir=resolve(root,'.cache/pinta-dense-pressure-old-browser')
export default {...base,testDir:resolve(root,'.cache'),testMatch:'qa-dense-pressure.flow.cjs',projects:[base.projects![0]],outputDir,reporter:[['list'],['json',{outputFile:resolve(outputDir,'report.json')}]],use:{...base.use,baseURL:`http://127.0.0.1:${port}`},webServer:{command:'bun scripts/serve-map-budget-e2e.ts',cwd:resolve(root,'packages/pinta'),env:{PINTA_BUDGET_PORT:String(port),PINTA_RENDER_PROOF:'1',PINTA_RENDER_BASELINE:'8d40b4b1bf9d64b7d74ff6ac5a78642358e03ded'},url:`http://127.0.0.1:${port}`,reuseExistingServer:false,timeout:120000}}
