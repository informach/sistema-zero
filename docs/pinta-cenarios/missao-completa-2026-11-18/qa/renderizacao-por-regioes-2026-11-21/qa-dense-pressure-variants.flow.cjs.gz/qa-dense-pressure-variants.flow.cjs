const {resolve}=require('node:path'),fs=require('node:fs');const root=resolve(__dirname,'..'),{test,expect}=require(require.resolve('@playwright/test',{paths:[resolve(root,'packages/studio')]}));
test('isolates source alpha and layer alpha on the actual archived renderer',async({page})=>{
 await page.goto('/');await page.waitForFunction(()=>!!window.runDensePressureRenderProbe);const variants=[];
 for(const variant of ['original','opaque','layer-opaque','both','normalized','readback']){
  const result=await page.evaluate(variant=>window.runDensePressureRenderProbe(variant),variant);expect(result).toHaveLength(4);variants.push({variant,cases:result.map(({preview,referencePreview,...entry})=>entry)})
 }
 fs.writeFileSync(resolve(root,'.cache/pinta-dense-pressure-variants.json'),JSON.stringify(variants,null,2)+'\n',{flag:'wx'});
});
