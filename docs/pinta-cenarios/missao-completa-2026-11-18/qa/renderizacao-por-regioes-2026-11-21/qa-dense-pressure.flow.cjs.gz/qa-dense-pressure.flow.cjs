const {resolve}=require('node:path'),fs=require('node:fs');
const root=resolve(__dirname,'..'),{test,expect}=require(require.resolve('@playwright/test',{paths:[resolve(root,'packages/studio')]}));
test('records the actual legacy dense pressure renderer',async({page})=>{
 await page.goto('/');await page.waitForFunction(()=>!!window.runDensePressureRenderProbe);
 const result=await page.evaluate(()=>window.runDensePressureRenderProbe());expect(result).toHaveLength(4);
 const label=process.env.PINTA_DENSE_RECEIPT;if(!label||!/^[a-z0-9-]+$/.test(label))throw Error('Receipt label required');
 for(const entry of result)if(entry.preview){fs.writeFileSync(resolve(root,'.cache',label+'-actual.png'),Buffer.from(entry.preview.split(',')[1],'base64'),{flag:'wx'});fs.writeFileSync(resolve(root,'.cache',label+'-reference.png'),Buffer.from(entry.referencePreview.split(',')[1],'base64'),{flag:'wx'})}
 fs.writeFileSync(resolve(root,'.cache',label+'.json'),JSON.stringify(result.map(({preview,referencePreview,...entry})=>entry),null,2)+'\n',{flag:'wx'});
});
