import {dirname,resolve} from 'node:path'
import {mkdir,writeFile} from 'node:fs/promises'
const root=resolve(import.meta.dir,'..'),baseline='47e21b13a0fb94995d24bf4d0fc041af2d0de952',out=resolve(import.meta.dir,'cache-content-profile-bundles')
await mkdir(out,{recursive:true})
for(const historical of [false,true]){
 const name=historical?'reference':'current',entry=resolve(out,`${name}-entry.ts`)
 await writeFile(entry,`import * as bench from '../../packages/pinta/scripts/map-grid-probe';Object.assign(window,{grid${historical?'Reference':'Current'}:bench});`)
 const plugin:Bun.BunPlugin={name:'actual-previous-chunk-cache',setup(build){build.onLoad({filter:/[\\/]src[\\/]tiles[\\/]chunks\.ts$/},args=>{const p=Bun.spawnSync(['git','show',`${baseline}:packages/pinta/src/tiles/chunks.ts`],{cwd:root,stdout:'pipe',stderr:'pipe'});if(p.exitCode)throw Error('Fonte anterior ausente');return{contents:p.stdout.toString(),loader:'ts',resolveDir:dirname(args.path)}})}}
 const built=await Bun.build({entrypoints:[entry],target:'browser',outdir:out,plugins:historical?[plugin]:[],minify:false,sourcemap:'external'})
 if(!built.success)throw new AggregateError(built.logs,'Compilação do laboratório falhou')
}
