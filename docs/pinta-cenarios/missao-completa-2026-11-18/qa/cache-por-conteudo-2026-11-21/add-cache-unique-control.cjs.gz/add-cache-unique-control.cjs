const fs=require('node:fs'),path='.cache/run-cache-content-ab.cjs';let source=fs.readFileSync(path,'utf8');
const needle="for(const kind of ['sparse','dense'])";if(source.split(needle).length!==3)throw Error('Case loops changed');
source=source.replaceAll(needle,"for(const kind of (cpu===1?['sparse','dense','dense-unique']:['sparse','dense']))");fs.writeFileSync(path,source);console.log('Added unique-content performance control');
