const fs = require('node:fs'), cp = require('node:child_process'), crypto = require('node:crypto');
const file = 'packages/pinta/src/components/editor/TileStrip.tsx', baseline = '30b108a9ddb69f18930fda4d7cff4d2211bd71e4';
const original = fs.readFileSync(file), sha = b => crypto.createHash('sha256').update(b).digest('hex');
const previous = cp.execFileSync('git', ['show', baseline + ':' + file]);
let result;
try {
  fs.writeFileSync(file, previous);
  result = cp.spawnSync('bun', ['--no-env-file', 'test', 'src/components/editor/tilesetRemapUi.test.tsx'], { cwd: 'packages/pinta', encoding: 'utf8' });
  const log = (result.stdout || '') + (result.stderr || '');
  fs.writeFileSync('.cache/remap-widget-red.log', log);
  if (result.status !== 1 || !log.includes('3 fail') || !log.includes('1 pass')) throw Error('Reprodução do componente incompleta');
} finally {
  fs.writeFileSync(file, original);
  if (!fs.readFileSync(file).equals(original)) throw Error('Fonte não restaurada');
}
console.log(JSON.stringify({ baseline, previousSha256: sha(previous), currentSha256: sha(original), restored: true, expectedFailures: 3, positiveControls: 1 }));
