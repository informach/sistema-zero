const fs = require('node:fs'), crypto = require('node:crypto'), zlib = require('node:zlib'), cp = require('node:child_process');
const out = 'docs/pinta-cenarios/missao-completa-2026-11-18/qa/remapeamento-por-regioes-2026-11-21/', baseline = '30b108a9ddb69f18930fda4d7cff4d2211bd71e4';
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex'), records = [];
const suite = fs.readFileSync('.cache/remap-full-pinta.log', 'utf8');
if (!suite.includes('2622 pass') || !suite.includes('0 fail')) throw Error('Suíte incompleta');
for (const name of ['remap-pinta-types', 'remap-studio-types']) if (fs.readFileSync('.cache/' + name + '.log', 'utf8').trim()) throw Error('Tipos incompletos');
function rows(suites) { return suites.flatMap(s => [...(s.specs || []).flatMap(spec => spec.tests.map(t => ({ title: spec.title, ...t }))), ...rows(s.suites || [])]); }
const reportPath = 'packages/studio/.cache/pinta-remap-results/report.json', report = JSON.parse(fs.readFileSync(reportPath)), tests = rows(report.suites);
if (report.stats.expected !== 27 || report.stats.unexpected || report.stats.flaky || report.stats.skipped || tests.some(t => t.results.length !== 1)) throw Error('Navegador incompleto');
const failed = tests.filter(t => t.expectedStatus === 'failed');
if (failed.length !== 9 || failed.some(t => t.results[0].status !== 'failed' || !t.results[0].error?.message.includes('expect(') || !t.results[0].attachments.some(a => a.name === 'revisoes'))) throw Error('Reprodução histórica divergente');
if (tests.filter(t => t.expectedStatus !== 'failed').some(t => t.results[0].status !== 'passed')) throw Error('Controle funcional falhou');
const workshopPath = 'packages/studio/.cache/pinta-brush-workshop-results/report.json', workshop = JSON.parse(fs.readFileSync(workshopPath));
if (workshop.stats.expected !== 33 || workshop.stats.unexpected || workshop.stats.flaky || workshop.stats.skipped || rows(workshop.suites).some(t => t.results.length !== 1 || t.results[0].status !== 'passed')) throw Error('Oficina incompleta');
fs.mkdirSync(out, { recursive: true });
function add(file, name) { const raw = fs.readFileSync(file), bytes = zlib.gzipSync(raw), target = name + '.gz'; fs.writeFileSync(out + target, bytes, { flag: 'wx' }); records.push({ file: target, bytes: bytes.length, sha256: sha(bytes), rawBytes: raw.length, rawSha256: sha(raw) }); }
for (const name of ['remap-regions-red', 'remap-regions-budget-red', 'remap-consumers-red', 'remap-widget-red', 'remap-integrated-focused', 'remap-full-pinta', 'remap-pinta-types', 'remap-studio-types', 'remap-browser', 'remap-workshop-browser', 'remap-biome', 'remap-diff']) add('.cache/' + name + '.log', name + '.log');
add(reportPath, 'playwright-remap-report.json'); add(workshopPath, 'playwright-workshop-report.json');
add('.cache/prove-remap-widget.cjs', 'prove-remap-widget.cjs'); add('.cache/archive-remap.cjs', 'archive-remap.cjs');
const sourceFiles = [...cp.execFileSync('git', ['diff', '--name-only', '--', '*.ts', '*.tsx', '*.json'], { encoding: 'utf8' }).trim().split('\n'), ...cp.execFileSync('git', ['ls-files', '--others', '--exclude-standard', '--', '*.ts', '*.tsx'], { encoding: 'utf8' }).trim().split('\n')].filter(Boolean);
const sources = sourceFiles.map(file => ({ file, sha256: sha(fs.readFileSync(file)), ...(cp.spawnSync('git', ['cat-file', '-e', baseline + ':' + file]).status === 0 ? { previousSha256: sha(cp.execFileSync('git', ['show', baseline + ':' + file])) } : {}) }));
fs.writeFileSync(out + 'index.json', JSON.stringify({ baseline, records, sources, browser: { currentWidgetPasses: 12, historicalPositiveControls: 3, historicalExpectedFailures: 9, currentRegionKernelPasses: 3, publicWorkshopPasses: 33, retries: 0 }, publicNative8: false, physicalIO3: false }, null, 2));
console.log(JSON.stringify({ records: records.length, sources: sources.length, suite: suite.slice(-170) }));
