import { readFileSync, writeFileSync } from 'node:fs'
import { pythonJsonWire } from '../packages/pinta/src/export/pythonJsonWire'
import { runPurePython } from '../packages/pinta/src/testing/runPurePython'

// Same 26 published binary64 boundaries as the regression, plus 100,000
// deterministic bit patterns. This is differential evidence, not an exhaustive proof.
const test = readFileSync(new URL('../packages/pinta/src/export/pythonJsonWire.test.ts', import.meta.url), 'utf8')
const boundaryText = test.slice(test.indexOf('const samples = ['), test.indexOf('let seed'))
const samples = [...boundaryText.matchAll(/'([0-9a-f]{16})'/g)].map(match => match[1])
if (samples.length !== 26) throw Error('Unexpected boundary fixture')
let seed = 0x123456789abcdefn
for (let n = 0; n < 100000; n++) {
  seed ^= seed << 13n
  seed ^= seed >> 7n
  seed ^= seed << 17n
  seed = BigInt.asUintN(64, seed)
  samples.push(seed.toString(16).padStart(16, '0'))
}
const actual = await runPurePython(pythonJsonWire,
  "print(json.dumps([_pinta_json_number(struct.unpack('>d',bytes.fromhex(h))[0]) for h in json.load(sys.stdin)]))",
  samples) as string[]
const mismatches = samples.flatMap((hex, i) => {
  const expected = JSON.stringify(Buffer.from(hex, 'hex').readDoubleBE())
  return actual[i] === expected ? [] : [{ hex, expected, actual: actual[i] }]
})
const result = { count: samples.length, mismatches, mismatchCount: mismatches.length }
writeFileSync(new URL('./pinta-python-json-numbers-probe.json', import.meta.url), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ count: result.count, mismatchCount: result.mismatchCount }))
if (mismatches.length) process.exitCode = 1
