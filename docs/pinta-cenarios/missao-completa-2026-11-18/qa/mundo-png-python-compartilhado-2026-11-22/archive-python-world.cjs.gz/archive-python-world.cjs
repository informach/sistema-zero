const fs=require('node:fs');
const path=require('node:path');
const {createHash}=require('node:crypto');
const {gzipSync}=require('node:zlib');
const root=path.resolve(__dirname,'..');
const target=path.join(root,'docs/pinta-cenarios/missao-completa-2026-11-18/qa/mundo-png-python-compartilhado-2026-11-22');
const physical='packages/studio/.cache/pinta-physical-regions-results/report.json';
const integration='packages/studio/.cache/pinta-integration-results/report.json';
for(const [file,count] of [[physical,4],[integration,12]]){
 const {stats}=JSON.parse(fs.readFileSync(path.join(root,file),'utf8'));
 if(stats.expected!==count||stats.unexpected||stats.flaky||stats.skipped)throw Error('Unexpected browser results: '+file);
}
const sha=b=>createHash('sha256').update(b).digest('hex');
const entries=[
 ['core-full.log','.cache/pinta-python-world-core-full.log'],
 ['pinta-full.log','.cache/pinta-python-world-full.log'],
 ['focused.log','.cache/pinta-python-world-focused.log'],
 ['core-focused.log','.cache/pinta-python-world-core-focused.log'],
 ['core-types.log','.cache/pinta-python-world-core-types.log'],
 ['pinta-types.log','.cache/pinta-python-world-pinta-types.log'],
 ['generator-types.log','.cache/pinta-python-world-generator-types.log'],
 ['biome.log','.cache/pinta-python-world-lint.log'],
 ['python-generated.log','.cache/pinta-python-world-generated.log'],
 ['js-generated.log','.cache/pinta-python-world-js-generated.log'],
 ['browser.log','.cache/pinta-python-world-browser.log'],
 ['integration-browser.log','.cache/pinta-python-world-integration-browser.log'],
 ['physical-report.json',physical],
 ['integration-report.json',integration],
 ['number-probe.log','.cache/pinta-python-world-number-probe.log'],
 ['number-probe.json','.cache/pinta-python-json-numbers-probe.json'],
 ['number-probe.ts','.cache/probe-pinta-python-json-numbers.ts'],
 ['verification.json','.cache/pinta-python-world-verification.json'],
 ['diff.log','.cache/pinta-python-world-diff.log'],
 ['archive-python-world.cjs','.cache/archive-pinta-python-world.cjs'],
];
const records=entries.map(([name,source])=>{const raw=fs.readFileSync(path.join(root,source)),gz=gzipSync(raw),file=name+'.gz';fs.writeFileSync(path.join(target,file),gz);return{file,bytes:gz.length,sha256:sha(gz),rawSha256:sha(raw)};});
const files=[
 'packages/core/scripts/pinta-scene-python-schema.ts',
 'packages/core/src/studio/pinta-image.ts',
 'packages/core/src/studio/pinta-region-image.ts',
 'packages/core/src/studio/pinta-scene-python-schema.test.ts',
 'packages/pinta/src/export/pythonSceneDocument.ts',
 'packages/pinta/src/export/pythonSceneSchemas.generated.ts',
 'packages/pinta/src/export/pythonJsonWire.test.ts',
 'packages/pinta/src/export/pythonJsonWire.ts',
 'packages/pinta/src/export/pythonRegionWorld.test.ts',
 'packages/pinta/src/export/pythonRegionWorld.ts',
 'packages/pinta/src/testing/runPurePython.ts',
];
const sources=files.map(file=>{const raw=fs.readFileSync(path.join(root,file));return{file,bytes:raw.length,sha256:sha(raw)};});
fs.writeFileSync(path.join(target,'index.json'),JSON.stringify({baseline:'51b57e7df7ede4c28dcaa58970d3639228d9356e',records,sources},null,2)+'\n');
console.log(JSON.stringify({records:records.length,sources:sources.length}));
