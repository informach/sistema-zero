const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const baseline='36c3ab7a826d8f5150ed73e41120e859613548af',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/admissao-de-metadados-2026-11-21/',records=[],sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const suite=fs.readFileSync('.cache/metadata-full.log','utf8');
if(!suite.includes('2650 pass')||!suite.includes('0 fail')||/[1-9]\d* skip/.test(suite)||!fs.readFileSync('.cache/metadata-admission-red.log','utf8').includes('3 fail'))throw Error('Suíte/reprodução incompleta');
for(const name of ['metadata-pinta-types','metadata-studio-types'])if(fs.readFileSync('.cache/'+name+'.log','utf8').trim())throw Error('Tipos incompletos');
function rows(suites){return suites.flatMap(s=>[...(s.specs||[]).flatMap(spec=>spec.tests),...rows(s.suites||[])])}
const reports=[['packages/studio/.cache/pinta-metadata-results/report.json',3],['packages/studio/.cache/pinta-resize-workshop-results/report.json',3],['packages/studio/.cache/pinta-integration-results/report.json',12]];
for(const [file,count]of reports){const r=JSON.parse(fs.readFileSync(file));if(r.stats.expected!==count||r.stats.unexpected||r.stats.skipped||r.stats.flaky||rows(r.suites).some(t=>t.results.length!==1||t.results[0].status!=='passed'))throw Error('Navegador incompleto: '+file)}
fs.mkdirSync(out,{recursive:true});
function add(file,name){const raw=fs.readFileSync(file),bytes=zlib.gzipSync(raw),target=name+'.gz';fs.writeFileSync(out+target,bytes,{flag:'wx'});records.push({file:target,bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)})}
for(const name of ['metadata-admission-red','metadata-focused','metadata-full','metadata-pinta-types','metadata-studio-types','metadata-browser','metadata-workshop-browser','metadata-integration-browser','metadata-biome','metadata-diff'])add('.cache/'+name+'.log',name+'.log');
for(const[i,[file]]of reports.entries())add(file,'playwright-'+i+'-report.json');
add('.cache/archive-metadata.cjs','archive-metadata.cjs');
const files=[...cp.execFileSync('git',['diff','--name-only','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n')].filter(Boolean);
const sources=files.map(file=>({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline+':'+file]).status===0?{previousSha256:sha(cp.execFileSync('git',['show',baseline+':'+file]))}:{})}));
const profiles=rows(JSON.parse(fs.readFileSync(reports[0][0])).suites).map(t=>{const a=t.results[0].attachments.find(a=>a.name==='admissao');if(!a)throw Error('Recibo ausente');const p=JSON.parse(a.body?Buffer.from(a.body,'base64'):fs.readFileSync(a.path));if(p.after.writes!==0||p.after.decodes!==0||!p.after.setRefused||p.before.writes!==2||p.before.setRefused||p.before.decodes<1||JSON.stringify(p.before.positive)!==JSON.stringify(p.after.positive))throw Error('Prova divergente');return {profile:t.projectName,...p}});
fs.writeFileSync(out+'index.json',JSON.stringify({baseline,records,sources,profiles,browserTests:18,retries:0,publicNative8:false,physicalIO3:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,browserTests:18,suite:suite.slice(-160)}));
