import {execFileSync} from 'node:child_process'
import {mkdirSync,writeFileSync} from 'node:fs'
import {resolve,basename} from 'node:path'
import {createHash} from 'node:crypto'
import {scene4Fixture,scene4BudgetFixture} from '../packages/core/tests/fixtures/pinta-region-scene'
import {readPintaRegionScene} from '../packages/core/src/studio/pinta-region-scene'
import {readPintaRegionImageData} from '../packages/core/src/studio/pinta-region-image'
const baseline='207b521f6',files=['pinta-region-scene.ts','pinta-region-image.ts'],folder='packages/core/.cache/region-preflight-baseline'
mkdirSync(folder,{recursive:true})
for(const name of files){const source=execFileSync('git',['show',baseline+':packages/core/src/studio/'+name],{encoding:'utf8'});writeFileSync(folder+'/'+name,source.replace(/from '(\.[^']+)'/g,(_,path)=>"from '"+resolve(files.includes(basename(path)+'.ts')?folder:'packages/core/src/studio',path).replaceAll('\\','/')+"'"))}
const previousScene=await import('../'+folder+'/pinta-region-scene.ts'),previousImage=await import('../'+folder+'/pinta-region-image.ts'),digest=createHash('sha256');let comparisons=0,accepted=0,refused=0
const sources=[scene4Fixture(),scene4BudgetFixture(1,1)]
for(const source of sources)for(const physics of [undefined,'legacy','precise'])for(let mutation=0;mutation<12;mutation++){
 const raw:any=JSON.parse(JSON.stringify({...source,...(physics?{physics}:{})}))
 if(mutation===1)raw.layers.push(raw.layers[0])
 if(mutation===2)raw.layers.find((l:any)=>l.kind==='tiles').tilesetId='missing'
 if(mutation===3)raw.layers[0].parentId='missing'
 if(mutation===4)raw.future=true
 if(mutation===5)raw.origin.col=-10001
 if(mutation===6)raw.layers.find((l:any)=>l.kind==='tiles').cells.chunks[0].data='bad'
 if(mutation===7)raw.cols=0
 if(mutation===8)raw.tilesets[0].solid=[255]
 if(mutation===9)raw.tilesets[0].animations={'0':[{tile:255,duration:100}]}
 if(mutation===10)raw.name='Bosque 🌳'
 if(mutation===11)raw.origin.row=9999
 for(const image of [false,true]){
  const text=JSON.stringify(image?{format:'pinta',version:5,kind:'map',name:raw.name,scale:1,scene:raw}:raw)
  const old=image?previousImage.readPintaRegionImageData(text):previousScene.readPintaRegionScene(text),current=image?readPintaRegionImageData(text):readPintaRegionScene(text)
  const a=JSON.stringify(old),b=JSON.stringify(current);if(a!==b)throw Error('Admission result changed '+[image,physics,mutation].join('/'));digest.update(a+'\n');comparisons++;if(current)accepted++;else refused++
 }
}
const result={baseline,comparisons,accepted,refused,privateReaderOutputsIdentical:true,sha256:digest.digest('hex')};writeFileSync('.cache/region-preflight-equivalence.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
