const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const baseline='207b521f6',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/admissao-de-mundos-regionais-2026-11-22/';
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex'),read=name=>fs.readFileSync('.cache/region-preflight-'+name+'.log','utf8');
for(const [name,count]of [['core-full',3251],['pinta-full',2748],['focused',26]])if(!read(name).includes(count+' pass')||!read(name).includes('0 fail')||/[1-9]\d* skip/.test(read(name)))throw Error(name+' incomplete');
for(const name of ['core-types','pinta-types','studio-types','generated','diff'])if(read(name).trim())throw Error(name+' not clean');
if(read('python-generated').trim()!=='pinta.py: o trecho da cena confere com o pacote portátil do Pinta.')throw Error('Python generation check missing');
if(!read('biome').includes('Checked 5 files'))throw Error('Lint missing');
const old=JSON.parse(fs.readFileSync('.cache/region-preflight-equivalence.json'));if(old.comparisons!==144||old.accepted!==16||old.refused!==128||!old.privateReaderOutputsIdentical)throw Error('Equivalence missing');
const before=JSON.parse(fs.readFileSync('.cache/region-preflight-before.json')),after=JSON.parse(fs.readFileSync('.cache/region-preflight-after.json'));if(before.decodesBeforeMetadataRefusal!==1||after.decodesBeforeMetadataRefusal!==0)throw Error('Probe incomplete');
if(cp.execFileSync('git',['diff',baseline,'--','packages/core/src/studio/pinta-scene-transform.generated.ts'],{encoding:'utf8'}).trim())throw Error('Unexpected portable source change');
const rows=suites=>suites.flatMap(s=>[...(s.specs||[]).flatMap(s=>s.tests),...rows(s.suites||[])]);
const reports=[['packages/studio/.cache/pinta-physical-regions-results/report.json',65,'physical-report.json'],['packages/studio/.cache/pinta-integration-results/report.json',12,'integration-report.json']];
for(const [file,count]of reports){const r=JSON.parse(fs.readFileSync(file));if(r.stats.expected!==count||r.stats.unexpected||r.stats.skipped||r.stats.flaky||rows(r.suites).some(t=>t.results.length!==1||t.results[0].status!=='passed'))throw Error('Browser failed '+file);}
fs.mkdirSync(out,{recursive:true});const records=[];
function add(raw,name){const bytes=zlib.gzipSync(raw),file=name+'.gz';fs.writeFileSync(out+file,bytes,{flag:'wx'});records.push({file,bytes:bytes.length,sha256:sha(bytes),rawSha256:sha(raw)});}
for(const name of ['core-full','pinta-full','focused','core-types','pinta-types','studio-types','generated','python-generated','biome','browser','browser-first','browser-focused','integration-browser','diff'])add(Buffer.from(read(name)),name+'.log');
for(const [file,,name]of reports)add(fs.readFileSync(file),name);
for(const name of ['region-preflight-equivalence.ts','region-preflight-equivalence.json','region-preflight-equivalence.log','region-preflight-before.ts','region-preflight-before.json','region-preflight-before.log','region-preflight-after.ts','region-preflight-after.json','region-preflight-after.log','archive-region-preflight.cjs'])add(fs.readFileSync('.cache/'+name),name);
const physical=JSON.parse(fs.readFileSync(reports[0][0]));let attached=0;
for(const test of rows(physical.suites))for(const result of test.results)for(const a of result.attachments||[]){if(a.name!=='metadados-mundo-regional.json')continue;const bytes=a.body?Buffer.from(a.body,'base64'):fs.readFileSync(a.path),proof=JSON.parse(bytes);if(!proof.headersBeforeCells||proof.decodesBeforeRefusal!==0||!proof.refusedWrongName)throw Error('World metadata proof failed');add(bytes,'world-metadata-'+attached+'.json');attached++;}
if(attached!==2)throw Error('Two browser profiles missing');
const files=[...new Set([...cp.execFileSync('git',['diff','--name-only','--','*.ts'],{encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts'],{encoding:'utf8'}).trim().split('\n')].filter(Boolean))];
const sources=files.map(file=>({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline+':'+file]).status===0?{previousSha256:sha(cp.execFileSync('git',['show',baseline+':'+file]))}:{})}));
const count=text=>({pass:Number(text.match(/(\d+) pass/)?.[1]),fail:0,skipped:0,assertions:Number(text.match(/(\d+) expect\(\) calls/)?.[1]),files:Number(text.match(/across (\d+) files/)?.[1])});
fs.writeFileSync(out+'index.json',JSON.stringify({baseline,records,sources,core:count(read('core-full')),pinta:count(read('pinta-full')),focused:count(read('focused')),privateReaderEquivalence:old,browser:{pass:77,physical:65,integration:12,retries:0},metadataWorldAdmission:true,completePngWorldLoader:false,pixelPreflight:false,boundedPngDecompressor:false,publicNative8:false,pythonRegionalGameplay:false,portableSourceUnchanged:true,phaserCarried:{commit:baseline,pass:10},additionalPhysicalDevices:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,browser:77,attached}));
