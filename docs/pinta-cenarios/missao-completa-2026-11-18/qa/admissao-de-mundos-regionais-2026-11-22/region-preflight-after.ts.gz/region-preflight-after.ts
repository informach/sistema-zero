import {scene4BudgetFixture} from '../packages/core/tests/fixtures/pinta-region-scene'
import {readPintaRegionScene} from '../packages/core/src/studio/pinta-region-scene'
import {writeFileSync} from 'node:fs'
const source=scene4BudgetFixture(1,1),valid=readPintaRegionScene(JSON.stringify(source))
if(!valid)throw Error('Positive control missing')
const invalid={...source,layers:source.layers.map(layer=>({...layer,tilesetId:'missing'}))}
let decodes=0;const original=globalThis.atob
globalThis.atob=text=>{decodes++;return original(text)}
let refused=false
try{refused=readPintaRegionScene(JSON.stringify(invalid))===null}finally{globalThis.atob=original}
if(!refused||decodes!==0)throw Error('Unexpected private admission order')
const result={privateScene4Only:true,positiveControl:true,invalidReferenceRefused:refused,decodesBeforeMetadataRefusal:decodes}
writeFileSync('.cache/region-preflight-after.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
