const {readFileSync,writeFileSync} = require('node:fs');
const {resolve} = require('node:path');
const {spawnSync} = require('node:child_process');
const root=resolve(__dirname,'..');
const file=resolve(root,'packages/pinta/src/export/pythonSceneSchemas.generated.ts');
const before=readFileSync(file);
const check=()=>spawnSync('bun',['--no-env-file','scripts/gen-pinta-scene-python.ts','--check'],{cwd:resolve(root,'packages/studio'),encoding:'utf8'});
let changed;
try {
  writeFileSync(file,Buffer.concat([before,Buffer.from('// stale probe\n')]));
  changed=check();
  if(changed.status!==1||!changed.stderr.includes('esquema portátil Python está desatualizado'))throw Error('Stale generated table did not fail as expected: '+changed.stderr);
} finally {
  writeFileSync(file,before);
}
const restored=check();
if(restored.status!==0||!readFileSync(file).equals(before))throw Error('Restored source did not pass: '+restored.stderr);
console.log(JSON.stringify({staleExit:changed.status,restoredExit:restored.status,restoredBytes:true},null,2));
