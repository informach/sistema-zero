const fs = require('node:fs');
const path = require('node:path');
const {createHash} = require('node:crypto');
const {gzipSync} = require('node:zlib');
const root=path.resolve(__dirname,'..');
const target=path.join(root,'docs/pinta-cenarios/missao-completa-2026-11-18/qa/admissao-python-de-cenas-regionais-2026-11-22');
const sha=b=>createHash('sha256').update(b).digest('hex');
for(const [file,count] of [['packages/studio/.cache/pinta-physical-regions-results/report.json',4],['packages/studio/.cache/pinta-integration-results/report.json',12]]){
  const {stats}=JSON.parse(fs.readFileSync(path.join(root,file),'utf8'));
  if(stats.expected!==count||stats.unexpected||stats.flaky||stats.skipped)throw Error('Unexpected browser outcome: '+file);
}
const entries=[
  ['core-full.log','.cache/pinta-python-document-core-full.log'],
  ['pinta-full.log','.cache/pinta-python-document-pinta-full-final.log'],
  ['focused.log','.cache/pinta-python-document-focused.log'],
  ['core-types.log','.cache/pinta-python-document-core-types.log'],
  ['pinta-types.log','.cache/pinta-python-document-pinta-types.log'],
  ['generator-types.log','.cache/pinta-python-document-generator-types.log'],
  ['generator-tsconfig.json','.cache/pinta-python-document-generator-tsconfig.json'],
  ['biome.log','.cache/pinta-python-document-lint.log'],
  ['python-generated.log','.cache/pinta-python-document-generated.log'],
  ['js-generated.log','.cache/pinta-python-document-js-generated.log'],
  ['schema-check.json','.cache/pinta-python-document-schema-check.json'],
  ['probe-schema-check.cjs','.cache/probe-python-schema-check.cjs'],
  ['native-before.log','.cache/pinta-python-document-native-before.log'],
  ['first-harness.log','.cache/pinta-python-document-first.log'],
  ['browser.log','.cache/pinta-python-document-browser.log'],
  ['integration-browser.log','.cache/pinta-python-document-integration.log'],
  ['physical-report.json','packages/studio/.cache/pinta-physical-regions-results/report.json'],
  ['integration-report.json','packages/studio/.cache/pinta-integration-results/report.json'],
  ['diff.log','.cache/pinta-python-document-diff.log'],
  ['archive-python-document.cjs','.cache/archive-pinta-python-document.cjs'],
  ['delivered-python.json','.cache/pinta-python-document-delivered.json'],
  ['generator-types-before.log','.cache/pinta-python-document-generator-types-before.log'],
];
const records=entries.map(([name,source])=>{const raw=fs.readFileSync(path.join(root,source)),gz=gzipSync(raw),file=name+'.gz';fs.writeFileSync(path.join(target,file),gz);return{file,bytes:gz.length,sha256:sha(gz),rawSha256:sha(raw)};});
const sources=[
  'packages/core/src/studio/pinta-scene.ts',
  'packages/core/src/studio/pinta-region-scene.ts',
  'packages/core/scripts/pinta-scene-python-schema.ts',
  'packages/core/src/studio/pinta-scene-python-schema.test.ts',
  'packages/pinta/src/export/pythonSceneDocument.ts',
  'packages/pinta/src/export/pythonSceneDocument.test.ts',
  'packages/pinta/src/export/pythonSceneSchemas.generated.ts',
  'packages/studio/scripts/gen-pinta-scene-python.ts',
].map(file=>{const raw=fs.readFileSync(path.join(root,file));return{file,bytes:raw.length,sha256:sha(raw)};});
fs.writeFileSync(path.join(target,'index.json'),JSON.stringify({baseline:'75fd6db9dc80f674241ee2acbc857de84478c275',records,sources},null,2)+'\n');
console.log(JSON.stringify({records:records.length,sources:sources.length}));
