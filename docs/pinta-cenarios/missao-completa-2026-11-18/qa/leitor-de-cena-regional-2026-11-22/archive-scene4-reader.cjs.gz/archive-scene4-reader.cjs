const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const baseline='327c9769a',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/leitor-de-cena-regional-2026-11-22/';
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex');
for(const[name,count]of [['core-full',3214],['pinta-full',2728]]){
  const log=fs.readFileSync('.cache/scene4-'+name+'.log','utf8');
  if(!log.includes(count+' pass')||!log.includes('0 fail')||/[1-9]\d* skip/.test(log))throw Error('Suíte incompleta: '+name);
}
for(const kind of ['core','pinta','studio'])if(fs.readFileSync('.cache/scene4-'+kind+'-types.log','utf8').trim())throw Error('Tipos incompletos');
for(const name of ['late-header','index-budget'])if(!fs.readFileSync('.cache/scene4-'+name+'-red.log','utf8').includes('1 fail'))throw Error('Controle de mutação ausente');
const legacy=JSON.parse(fs.readFileSync('.cache/scene4-legacy-equivalence.json'));
if(legacy.cases!==624||legacy.accepted!==48||legacy.refused!==576||!legacy.outputAndIssueOrderIdentical)throw Error('Equivalência legada incompleta');
if(!fs.readFileSync('.cache/scene4-biome.log','utf8').includes('Checked 7 files')||fs.readFileSync('.cache/scene4-diff.log','utf8').trim())throw Error('Lint/diff incompletos');
const rows=suites=>suites.flatMap(s=>[...(s.specs||[]).flatMap(s=>s.tests),...rows(s.suites||[])]);
const reports=[['packages/studio/.cache/pinta-physical-regions-results/report.json',55,'persistence-report.json'],['packages/studio/.cache/pinta-integration-results/report.json',12,'pinta-studio-report.json']];
const metrics=[];
for(const[file,count]of reports){
 const report=JSON.parse(fs.readFileSync(file));
 if(report.stats.expected!==count||report.stats.unexpected||report.stats.skipped||report.stats.flaky||rows(report.suites).some(test=>test.results.length!==1||test.results[0].status!=='passed'))throw Error('Navegador incompleto: '+file);
 for(const test of rows(report.suites))for(const a of test.results[0].attachments||[])if(a.name==='scene4-decode.json')metrics.push(a);
}
if(metrics.length!==2)throw Error('Medições do leitor ausentes');
fs.mkdirSync(out,{recursive:true});
const records=[];
function addBytes(raw,name){const bytes=zlib.gzipSync(raw),file=out+name+'.gz';if(fs.existsSync(file)){if(!fs.readFileSync(file).equals(bytes))throw Error('Recibo divergente: '+file);}else fs.writeFileSync(file,bytes,{flag:'wx'});records.push({file:name+'.gz',bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)});}
function add(file,name){addBytes(fs.readFileSync(file),name);}
for(const name of ['core-regression-first','core-focused','core-full','pinta-full','core-types-first','core-types-fixture','core-types','pinta-types','studio-types','late-header-red','index-budget-red','browser','integration-browser','biome','diff'])add('.cache/scene4-'+name+'.log',name+'.log');
for(const[file,,name]of reports)add(file,name);
add('.cache/scene4-legacy-equivalence.json','legacy-equivalence.json');
add('.cache/scene4-legacy-equivalence.ts','legacy-equivalence.ts');
add('.cache/scene4-guard-proofs.cjs','guard-proofs.cjs');
add('.cache/refactor-scene-validation.py','refactor-scene-validation.py');
add('.cache/archive-scene4-reader.cjs','archive-scene4-reader.cjs');
const measurements=[];
for(const[index,a]of metrics.entries()){
 const raw=a.path?fs.readFileSync(a.path):Buffer.from(a.body,'base64'),data=JSON.parse(raw);
 if(data.bytes!==4194304||data.chunks!==2048||data.layers!==32||!data.publicRefused)throw Error('Medição inesperada');
 measurements.push(data);addBytes(raw,'scene4-decode-'+index+'.json');
}
const files=[...new Set([...cp.execFileSync('git',['diff','--name-only','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n')].filter(Boolean))];
const sources=files.map(file=>({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline+':'+file]).status===0?{previousSha256:sha(cp.execFileSync('git',['show',baseline+':'+file]))}:{})}));
fs.writeFileSync(out+'index.json',JSON.stringify({baseline,records,sources,core:{pass:3214,fail:0,skipped:0,assertions:160353,files:200},pinta:{pass:2728,fail:0,skipped:0,assertions:Number(fs.readFileSync('.cache/scene4-pinta-full.log','utf8').match(/(\d+) expect\(\) calls/)?.[1]),files:252},browser:{pass:67,retries:0,persistence:55,integration:12,newScene4:4,profiles:['desktop','cpu-4x']},legacy,measurements,scene4Reader:true,scene4Writer:false,png5:false,publicScene:3,publicNative:7,cloud:6,physical3Private:true,latencySLA:false,additionalPhysicalDevices:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,core:3214,pinta:2728,browser:67}));
