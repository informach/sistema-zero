const fs=require('node:fs'),cp=require('node:child_process'),path=require('node:path');
const file='packages/core/src/studio/pinta-region-scene.ts',original=fs.readFileSync(file,'utf8');
const begin=original.indexOf('    // Admit every map/definition'),end=original.indexOf('    const decodeMap =',begin);
if(begin<0||end<0)throw Error('Guarda ausente');
const budget='      if (indexBytes > PINTA_REGION_SCENE_MAX_INDEX_BYTES) return null';
if(!original.includes(budget))throw Error('Orçamento ausente');
const cases=[
  ['late-header',original.slice(0,begin)+original.slice(end),'every reusable definition'],
  ['index-budget',original.replace(budget,''),'aggregate index budgets'],
];
try {
  for(const[name,source,pattern]of cases){
    fs.writeFileSync(file,source);
    const result=cp.spawnSync('C:/Users/tocha/.bun/bin/bun.exe',['--no-env-file','test','src/studio/pinta-region-scene.test.ts','--test-name-pattern',pattern],{cwd:path.resolve('packages/core'),encoding:'utf8',windowsHide:true,timeout:15000});
    const output=(result.stdout||'')+(result.stderr||'');
    fs.writeFileSync('.cache/scene4-'+name+'-red.log',output);
    if(result.status===0||!output.includes('1 fail'))throw Error('Mutante sobreviveu: '+name);
  }
} finally {fs.writeFileSync(file,original);}
console.log(JSON.stringify({guardsKilled:cases.length,sourceRestored:fs.readFileSync(file,'utf8')===original}));
