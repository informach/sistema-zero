from pathlib import Path
p=Path('packages/core/src/studio/pinta-scene.ts')
s=p.read_text(encoding='utf-8')
start=s.index('export const PintaSceneSchema = z\n')
refine=s.index('  .superRefine((s, ctx) => {',start)
end=s.index('\nexport type PintaScene =',refine)
base=s[start:refine].replace('export const PintaSceneSchema = z\n','export const PintaSceneBaseSchema = z\n',1)
body=s[refine+len('  .superRefine((s, ctx) => {'):end]
assert body.endswith('\n  })')
body=body[:-len('\n  })')]
body=body.replace('layers: z.infer<typeof PintaSceneLayerSchema>[],','layers: PintaSceneCellsLayer<Cells>[],')
body=body.replace('cells += l.cells.length','cells += policy.count(l.cells)')
old='''l.cells.length !== cols * rows ||
            !sets.has(l.tilesetId) ||
            l.cells.some((c) => c >= 0 && (c & 4095) >= (ts?.count ?? 0))'''
assert old in body
body=body.replace(old,'''!sets.has(l.tilesetId) ||
            !policy.valid(l.cells, cols, rows, ts?.count ?? 0)''',1)
helper='''
/** Shared semantic checks; each cell format owns its shape, bounds and payload admission. */
export type PintaSceneCellsLayer<Cells> =
  | Exclude<z.infer<typeof PintaSceneLayerSchema>, { kind: 'tiles' }>
  | (Omit<Extract<z.infer<typeof PintaSceneLayerSchema>, { kind: 'tiles' }>, 'cells'> & { cells: Cells })
export type PintaSceneCellsDocument<Cells> = Omit<
  z.infer<typeof PintaSceneBaseSchema>, 'version' | 'layers' | 'sets'
> & {
  version: number
  layers: PintaSceneCellsLayer<Cells>[]
  sets?: Array<{ id: string; cols: number; rows: number; layers: PintaSceneCellsLayer<Cells>[] }>
}
export function validatePintaSceneCells<Cells>(
  s: PintaSceneCellsDocument<Cells>,
  ctx: z.RefinementCtx,
  policy: {
    count(cells: Cells): number
    valid(cells: Cells, cols: number, rows: number, tileCount: number): boolean
  },
): void {'''
footer='''
}

export const PintaSceneSchema = PintaSceneBaseSchema.superRefine((scene, ctx) =>
  validatePintaSceneCells(scene, ctx, {
    count: (cells) => cells.length,
    valid: (cells, cols, rows, tileCount) =>
      cells.length === cols * rows && !cells.some((cell) => cell >= 0 && (cell & 4095) >= tileCount),
  }),
)
'''
s=s[:start]+base+helper+body+footer+s[end:]
p.write_text(s,encoding='utf-8')
