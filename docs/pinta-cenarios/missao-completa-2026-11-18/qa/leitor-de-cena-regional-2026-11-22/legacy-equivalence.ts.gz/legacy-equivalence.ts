import { execFileSync } from 'node:child_process'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { PintaSceneSchema } from '../packages/core/src/studio/pinta-scene'
const parent=execFileSync('git',['show','327c9769a:packages/core/src/studio/pinta-scene.ts'],{encoding:'utf8'})
mkdirSync('packages/core/.cache',{recursive:true})
writeFileSync('packages/core/.cache/scene3-327c9769a.ts',parent)
const old=await import('../packages/core/.cache/scene3-327c9769a.ts')
let cases=0,accepted=0,refused=0
const digest=createHash('sha256')
function compare(raw:unknown){
  const a=old.PintaSceneSchema.safeParse(raw),b=PintaSceneSchema.safeParse(raw)
  const normalize=(r:typeof b)=>JSON.stringify(r.success?{success:true,data:r.data}:{success:false,issues:r.error.issues})
  const expected=normalize(a),actual=normalize(b)
  if(expected!==actual)throw Error('Mudança legada no caso '+cases)
  digest.update(expected);cases++;if(b.success)accepted++;else refused++
  return b.success
}
for(let version=1;version<=3;version++)for(let seed=0;seed<16;seed++){
  const source={version,id:'legacy',name:'Vila',tileSize:16,cols:4,rows:4,
    tilesets:[{id:'ground',name:'Chão',image:'png',columns:2,count:4,solid:[0],platform:[1],animations:{2:[{tile:3,duration:100}]}}],
    layers:[{kind:'group',id:'group',name:'Vila',visible:true,offsetX:seed/4,parallaxX:0.5},
      {kind:'tiles',id:'floor',name:'Chão',visible:true,parentId:'group',tilesetId:'ground',cells:Array.from({length:16},(_,i)=>(seed+i)%4),front:true,opacity:0.5},
      {kind:'objects',id:'objects',name:'Objetos',visible:true,objects:[{
        id:'hero-object',name:'Morador',type:'',x:seed-3.5,y:8.25,width:16,height:16,properties:{life:{type:'int',value:3}},
        art:{assetId:'hero',...(version>=2?{animationId:'walk'}:{})},...(version===3?{collision:true}:{}),
      }]},
    ],
    art:[{id:'hero',image:'png',width:16,height:16,...(version>=2?{sprite:{frameWidth:16,frameHeight:16,columns:1,animations:[{id:'walk',name:'Andar',loop:true,frames:[{tile:0,duration:100}]}]}}:{})}],
    ...(version>=2?{resources:[{id:'ground',sourceId:'live-ground',capturedAt:1}]}:{}),
  }
  if(!compare(source))throw Error('Controle positivo recusado')
  const variants:unknown[]=[
    {...source,version:4},{...source,cols:257},{...source,future:true},
    {...source,tilesets:[]},{...source,tilesets:[...source.tilesets,...source.tilesets]},
    {...source,art:[]},{...source,resources:[{id:'missing',sourceId:'live',capturedAt:1}]},
    {...source,layers:source.layers.map(l=>l.kind==='tiles'?{...l,cells:[0]}:l)},
    {...source,layers:source.layers.map(l=>l.kind==='tiles'?{...l,cells:new Array(16).fill(9)}:l)},
    {...source,layers:source.layers.map(l=>l.kind==='tiles'?{...l,parentId:'missing'}:l)},
    {...source,layers:source.layers.map(l=>l.kind==='tiles'?{...l,front:false}:l)},
    {...source,layers:source.layers.map(l=>l.kind==='objects'?{...l,objects:[...l.objects!,...l.objects!]}:l)},
  ]
  for(const variant of variants)compare(variant)
}
if(!accepted||!refused)throw Error('Comparação sem controles')
const result={baseline:'327c9769a',cases,accepted,refused,outputAndIssueOrderIdentical:true,sha256:digest.digest('hex'),sourceSha256:createHash('sha256').update(readFileSync('packages/core/src/studio/pinta-scene.ts')).digest('hex')}
writeFileSync('.cache/scene4-legacy-equivalence.json',JSON.stringify(result,null,2))
console.log(JSON.stringify(result))
