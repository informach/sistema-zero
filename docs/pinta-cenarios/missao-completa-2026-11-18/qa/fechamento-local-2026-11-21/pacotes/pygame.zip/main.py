import argparse
import json
from pathlib import Path
import pygame
from pinta_cenario import Mundo

parser = argparse.ArgumentParser(description='Meu jogo do Pinta')
parser.add_argument('--frames', type=int, default=0, help='Encerrar depois deste número de quadros')
parser.add_argument('--screenshot', help='Guardar a última imagem em PNG')
args = parser.parse_args()
pygame.init()
tela = pygame.display.set_mode((640, 480))
pygame.display.set_caption('Meu mapa do Pinta')
raiz = Path(__file__).parent
mundo = Mundo(raiz, json.loads((raiz / 'start.json').read_text(encoding='utf-8')))
clock = pygame.time.Clock()
frames = 0
rodando = True
while rodando:
    dt = min(clock.tick(60) / 1000, 0.05)
    for event in pygame.event.get():
        if event.type == pygame.QUIT or event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            rodando = False
    keys = pygame.key.get_pressed()
    mundo.mover((keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * 120 * dt, (keys[pygame.K_DOWN] - keys[pygame.K_UP]) * 120 * dt)
    tela.fill('#e8edf4')
    mundo.desenhar(tela)
    mundo.desenhar(tela, frente=True)
    pygame.display.flip()
    frames += 1
    if args.frames and frames >= args.frames:
        rodando = False
if args.screenshot:
    pygame.image.save(tela, args.screenshot)
print(f'Pinta: {mundo.nome} / {len(mundo.dados["layers"])} camadas / {frames} quadros')
pygame.quit()
