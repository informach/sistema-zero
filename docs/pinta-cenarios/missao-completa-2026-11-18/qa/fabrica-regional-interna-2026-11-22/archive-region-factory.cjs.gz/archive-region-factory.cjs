const fs = require('node:fs'), cp = require('node:child_process'), crypto = require('node:crypto'), zlib = require('node:zlib');
const baseline = 'af9628306', out = 'docs/pinta-cenarios/missao-completa-2026-11-18/qa/fabrica-regional-interna-2026-11-22/';
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const suite = fs.readFileSync('.cache/region-factory-full.log','utf8');
if (!suite.includes('2721 pass') || !suite.includes('0 fail') || /[1-9]\d* skip/.test(suite)) throw Error('Suíte incompleta');
for (const kind of ['pinta','studio']) if (fs.readFileSync('.cache/region-factory-' + kind + '-types.log','utf8').trim()) throw Error('Tipos incompletos');
const focused = fs.readFileSync('.cache/region-factory-focused.log','utf8');
if (!focused.includes('55 pass') || !focused.includes('0 fail')) throw Error('Focados incompletos');
if (!fs.readFileSync('.cache/region-factory-host-boundary.log','utf8').includes('8 pass')) throw Error('Fronteira do host incompleta');
const reportPath = 'packages/studio/.cache/pinta-physical-regions-results/report.json', report = JSON.parse(fs.readFileSync(reportPath));
const rows = suites => suites.flatMap(s => [...(s.specs || []).flatMap(s => s.tests), ...rows(s.suites || [])]);
if (report.stats.expected !== 47 || report.stats.unexpected || report.stats.skipped || report.stats.flaky || rows(report.suites).some(t => t.results.length !== 1 || t.results[0].status !== 'passed')) throw Error('Navegador incompleto');
const integrationPath = 'packages/studio/.cache/pinta-integration-results/report.json', integration = JSON.parse(fs.readFileSync(integrationPath));
if (integration.stats.expected !== 12 || integration.stats.unexpected || integration.stats.skipped || integration.stats.flaky || rows(integration.suites).some(t => t.results.length !== 1 || t.results[0].status !== 'passed')) throw Error('Integração incompleta');
if (!fs.readFileSync('.cache/region-factory-biome.log','utf8').includes('Checked 7 files') || fs.readFileSync('.cache/region-factory-diff.log','utf8').trim()) throw Error('Lint/diff incompletos');
fs.mkdirSync(out,{recursive:true});
const records = [];
function add(file,name) {
  const raw = fs.readFileSync(file), bytes = zlib.gzipSync(raw);
  fs.writeFileSync(out + name + '.gz',bytes,{flag:'wx'});
  records.push({file:name + '.gz',bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)});
}
for (const name of ['focused-first','focused','host-boundary','browser-focused','browser','browser-final-guards','integration-browser','full','pinta-types-first','pinta-types-fixture-failed','pinta-types','studio-types-fixture-failed','studio-types','biome','diff']) add('.cache/region-factory-' + name + '.log',name + '.log');
add(reportPath,'playwright-report.json');
add(integrationPath,'pinta-studio-report.json');
add('.cache/archive-region-factory.cjs','archive-region-factory.cjs');
const files = [...new Set([
  ...cp.execFileSync('git',['diff','--name-only','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),
  ...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),
].filter(Boolean))];
const sources = files.map(file => ({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline + ':' + file]).status === 0 ? {previousSha256:sha(cp.execFileSync('git',['show',baseline + ':' + file]))} : {})}));
fs.writeFileSync(out + 'index.json',JSON.stringify({baseline,records,sources,suite:{pass:2721,fail:0,skipped:0,assertions:Number(suite.match(/(\d+) expect\(\) calls/)?.[1]),files:250},focused:{pass:55,assertions:217,files:5},browser:{pass:47,retries:0,profiles:['desktop','cpu-4x'],realIndexedDB:true,factory:4,previous:43},factory:{sharedImplementation:true,privateOptIn:true,cellEditPuts:3,cellEditChunkPuts:1,completeGalleryBudget:true,quotaFailureAtomic:true},publicNative8:false,host8:false,partialCloudInventory:false,readOnDemand:false,additionalPhysicalDevices:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,pass:2721,browser:47}));
