const fs = require('node:fs');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const path = require('node:path');
const files = ['packages/pinta/src/tiles/resourceVersions.ts', 'packages/pinta/src/tiles/regionMap.ts'];
const originals = files.map(file => fs.readFileSync(file));
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
const previous = files.map(file => cp.execFileSync('git', ['show', '549b930b9a46d2cb2cd73dcf16863007f9ff2fe5:' + file]));
let result;
try {
  files.forEach((file, i) => fs.writeFileSync(file, previous[i]));
  result = cp.spawnSync('bun', ['--no-env-file', 'test', 'src/tiles/resourceVersionsRegions.test.ts'], { cwd: path.resolve('packages/pinta'), encoding: 'utf8' });
  fs.writeFileSync('.cache/resource-region-red.log', (result.stdout || '') + (result.stderr || ''));
  if (result.status !== 1 || !((result.stdout || '') + (result.stderr || '')).includes('8 fail')) throw Error('A versão anterior não reproduziu as recusas esperadas');
} finally {
  files.forEach((file, i) => fs.writeFileSync(file, originals[i]));
  if (files.some((file, i) => hash(fs.readFileSync(file)) !== hash(originals[i]))) throw Error('A fonte atual não foi restaurada');
}
console.log(JSON.stringify({ previousCommit: '549b930b9a46d2cb2cd73dcf16863007f9ff2fe5', previousExit: result.status, sourceRestored: true, sources: files.map((file, i) => ({ file, sha256: hash(originals[i]) })) }));
