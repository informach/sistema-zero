const fs = require('node:fs');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const out = 'docs/pinta-cenarios/missao-completa-2026-11-18/qa/versoes-de-recursos-por-regioes-2026-11-21/';
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const records = [];
const suite = fs.readFileSync('.cache/resource-region-suite.log', 'utf8');
if (!suite.includes('2592 pass') || !suite.includes('0 fail')) throw Error('Suíte incompleta');
for (const name of ['resource-region-types', 'resource-region-studio-types'])
  if (fs.readFileSync('.cache/' + name + '.log', 'utf8').trim()) throw Error('Tipos com erros: ' + name);
if (!fs.readFileSync('.cache/resource-region-red.log', 'utf8').includes('8 fail')) throw Error('Reprodução histórica incompleta');
const reports = [
  ['packages/studio/.cache/pinta-resources-cpu-results/report.json', 5],
  ['packages/studio/.cache/pinta-resource-controls-results/report.json', 2],
];
function rows(suites) { return suites.flatMap(s => [...(s.specs || []).flatMap(s => s.tests.map(t => ({ ...t, title: s.title }))), ...rows(s.suites || [])]); }
for (const [file, count] of reports) {
  const r = JSON.parse(fs.readFileSync(file));
  const tests = rows(r.suites);
  if (r.stats.expected !== count || r.stats.unexpected || r.stats.flaky || r.stats.skipped || tests.some(t => t.results.length !== 1 || t.results[0].status !== 'passed')) throw Error('Ensaios incompletos: ' + file);
}
fs.mkdirSync(out, { recursive: true });
function add(file, name) {
  const raw = fs.readFileSync(file), compressed = zlib.gzipSync(raw), target = name + '.gz';
  fs.writeFileSync(out + target, compressed, { flag: 'wx' });
  records.push({ file: target, bytes: compressed.length, sha256: sha(compressed), rawBytes: raw.length, rawSha256: sha(raw) });
}
for (const name of ['resource-region-red', 'resource-region-migration-red', 'resource-region-source-id-red', 'resource-region-focused', 'resource-region-types', 'resource-region-studio-types', 'resource-region-suite', 'resource-region-browser', 'resource-region-controls-browser', 'resource-region-biome', 'resource-region-diff']) add('.cache/' + name + '.log', name + '.log');
for (const [i, [file]] of reports.entries()) add(file, 'playwright-' + i + '-report.json');
for (const test of rows(JSON.parse(fs.readFileSync(reports[1][0])).suites)) {
  const attachment = test.results[0].attachments.find(a => a.name === 'versao-e-animacao');
  if (!attachment) throw Error('Imagem do controle ausente');
  const raw = attachment.body ? Buffer.from(attachment.body, 'base64') : fs.readFileSync(attachment.path);
  const file = 'controle-' + test.projectName + '.png';
  fs.writeFileSync(out + file, raw, { flag: 'wx' });
  records.push({ file, bytes: raw.length, sha256: sha(raw) });
}
for (const file of ['.cache/prove-resource-regions.cjs', '.cache/archive-resource-regions.cjs']) add(file, file.split('/').pop());
const sources = [
  'packages/pinta/src/tiles/resourceVersions.ts', 'packages/pinta/src/tiles/resourceVersionsRegions.test.ts',
  'packages/pinta/src/core/project.ts', 'packages/pinta/src/core/mapResourceVersions.ts',
  'packages/pinta/src/core/copy.ts', 'packages/pinta/src/components/editor/mapTools/resourceVersionMessages.ts',
  'packages/pinta/src/tiles/regionMap.ts',
  'packages/studio/e2e/pinta-resources-scenes.flow.ts', 'packages/studio/playwright.pinta-resources.config.ts',
  'packages/studio/playwright.pinta.config.ts', 'packages/pinta/scripts/homologacao/resources.ts',
].map(file => ({ file, sha256: sha(fs.readFileSync(file)) }));
fs.writeFileSync(out + 'index.json', JSON.stringify({ baseline: '549b930b9a46d2cb2cd73dcf16863007f9ff2fe5', records, sources, browserTests: 7, native8Public: false, externalEngineQualification: false }, null, 2));
console.log(JSON.stringify({ records: records.length, sources: sources.length, suite: suite.slice(-220), browserTests: 7 }));
