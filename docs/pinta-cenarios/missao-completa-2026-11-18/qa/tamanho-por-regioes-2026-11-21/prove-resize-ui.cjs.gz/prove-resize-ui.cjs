const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto');
const baseline='85f8dc4a718886da3f888464108ca91e79bc9549', files=['packages/pinta/src/components/editor/ResizeAssetDialog.tsx','packages/pinta/src/components/editor/EditorScreen.tsx'], originals=files.map(f=>fs.readFileSync(f)), previous=files.map(f=>cp.execFileSync('git',['show',baseline+':'+f]));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
try {
  files.forEach((f,i)=>fs.writeFileSync(f,previous[i]));
  const r=cp.spawnSync('bun',['--no-env-file','test','src/components/editor/resizeRefusalUi.test.tsx','src/components/editor/resizeUi.test.tsx'],{cwd:'packages/pinta',encoding:'utf8'}),log=(r.stdout||'')+(r.stderr||'');
  fs.writeFileSync('.cache/resize-ui-red.log',log);
  if(r.status!==1||!log.includes('2 fail')||!log.includes('6 pass'))throw Error('Reprodução incompleta');
}finally{files.forEach((f,i)=>{fs.writeFileSync(f,originals[i]);if(!fs.readFileSync(f).equals(originals[i]))throw Error('Fonte não restaurada')})}
console.log(JSON.stringify({baseline,restored:true,expectedFailures:2,positiveControls:6,sources:files.map((file,i)=>({file,currentSha256:sha(originals[i]),previousSha256:sha(previous[i])}))}));
