from pathlib import Path
import re
p = Path('packages/pinta/src/state/localAssetAuthority.ts')
s = p.read_text(encoding='utf-8')
assert s.count('function validAsset(') == 1
s = s.replace("import { pintaValuesEqual as localValuesEqual }", "import type { PintaMemoryAsset } from '../core/assetMemory'\nimport { pintaValuesEqual as localValuesEqual }", 1)
s = s.replace('export interface LocalDocument {', 'export interface LocalDocument<Asset extends PintaMemoryAsset = PintaAsset> {', 1)
s = s.replace('  asset: PintaAsset | null', '  asset: Asset | null', 1)
snapshot = '''export interface LocalSnapshot {
  assets: Map<string, PintaAsset>
  documents: Map<string, LocalDocument>
  issues: LocalReadIssue[]
  recovered: PintaAsset[]
  baseline: PintaAsset[]
}
'''
assert snapshot in s
s = s.replace(snapshot, '', 1)
offset = s.index('function validAsset(')
head, body = s[:offset], s[offset:]
body = re.sub(r'\bPintaAsset\b', 'Asset', body)
body = re.sub(r'\bLocalDocument\b', 'LocalDocument<Asset>', body)
body = re.sub(r'\bLocalSnapshot\b', 'LocalSnapshot<Asset>', body)
for before, after in [('PINTA_MAX_SCHEMA', 'format.maxSchema'), ('sanitizePintaAsset', 'format.sanitize'), ('pintaAssetSchema', 'format.schema'), ('withPintaSchemaStamp', 'format.stamp')]:
    body = re.sub(r'\b' + before + r'\b', after, body)
body = body.replace('export function ', 'function ')
budget = '''  const projected = galleryBackupByteLength([...after])
  if (projected > MAX_BACKUP_FILE_BYTES && projected >= galleryBackupByteLength([...before]))
    throw new PintaStorageBudgetError(projected)'''
assert budget in body
body = body.replace(budget, '  format.checkBudget(before, after)', 1)
api = '''export interface LocalSnapshot<Asset extends PintaMemoryAsset = PintaAsset> {
  assets: Map<string, Asset>
  documents: Map<string, LocalDocument<Asset>>
  issues: LocalReadIssue[]
  recovered: Asset[]
  baseline: Asset[]
}

/** Internal format policy; the default exports retain the existing public 0–7 contract. */
export interface LocalAssetFormat<Asset extends PintaMemoryAsset> {
  readonly maxSchema: number
  sanitize(raw: unknown): Asset | null
  stamp(asset: Asset): Asset
  schema(asset: Asset): number
  checkBudget(before: readonly Asset[], after: readonly Asset[]): void
}

/** Same authority, causal revisions, tombstones and recovery for every admitted cell format. */
export function createLocalAssetAuthority<Asset extends PintaMemoryAsset>(format: LocalAssetFormat<Asset>) {
'''
tail = '''
  return { selectLocalAssetRecords, resolveLocalRecords, protectAsset, checkLocalBudget, writeLocalRecords, deleteLocalRecord }
}

const legacyAuthority = createLocalAssetAuthority<PintaAsset>({
  maxSchema: PINTA_MAX_SCHEMA,
  sanitize: sanitizePintaAsset,
  stamp: withPintaSchemaStamp,
  schema: pintaAssetSchema,
  checkBudget(before, after) {
    const projected = galleryBackupByteLength([...after])
    if (projected > MAX_BACKUP_FILE_BYTES && projected >= galleryBackupByteLength([...before]))
      throw new PintaStorageBudgetError(projected)
  },
})

export const { selectLocalAssetRecords, resolveLocalRecords, protectAsset, checkLocalBudget, writeLocalRecords, deleteLocalRecord } = legacyAuthority
'''
p.write_text(head + api + '\n'.join('  ' + line if line else '' for line in body.splitlines()) + '\n' + tail, encoding='utf-8')
