const fs=require('node:fs'),http=require('node:http'),crypto=require('node:crypto'),cp=require('node:child_process');
const {chromium}=require('../packages/studio/node_modules/@playwright/test');
const server=http.createServer((req,res)=>{const name=req.url?.slice(1);if(['current-entry.js','reference-entry.js'].includes(name)){res.setHeader('Content-Type','text/javascript');res.end(fs.readFileSync('.cache/grid-profile-bundles/'+name));}else{res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><title>Canvas ABBA frame lab</title><script type="module" src="/current-entry.js"></script><script type="module" src="/reference-entry.js"></script></html>')}});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({headless:true}),blocks=[];try{
 const page=await browser.newPage({viewport:{width:1200,height:900}}),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>!!window.gridCurrent&&!!window.gridReference);
 const cdp=await page.context().newCDPSession(page);
 for(const cpu of [1,4])for(const kind of ['sparse','dense'])for(const [index,version]of['Reference','Current','Current','Reference'].entries()) {
  await cdp.send('Emulation.setCPUThrottlingRate',{rate:cpu});
  await page.evaluate(()=>{window.gridCurrent.disposeGridBench();window.gridReference.disposeGridBench()});await cdp.send('HeapProfiler.collectGarbage');
  const result=await page.evaluate(async({version,kind})=>{
    const api=version==='Current'?window.gridCurrent:window.gridReference,metadata=api.prepareGridBench(kind);
    for(let i=0;i<3;i++){await new Promise(requestAnimationFrame);api.sampleGridFrames(1)}
    const times=[];for(let i=0;i<15;i++){await new Promise(requestAnimationFrame);times.push(api.sampleGridFrames(1).times[0])}
    const pixels=await api.gridPixels(),moves=api.countGridMoves(),sorted=[...times].sort((a,b)=>a-b);
    return{metadata,times,pixels,moves,p50:sorted[7],p95:sorted[14]}
  },{version,kind});
  const block={cpu,kind,index,version,...result};blocks.push(block);console.log(JSON.stringify({...block,times:undefined}));
 }
 if(errors.length)throw Error(errors.join('\n'));
 const summaries=[];for(const cpu of [1,4])for(const kind of ['sparse','dense'])for(const version of ['Reference','Current']){const selected=blocks.filter(b=>b.cpu===cpu&&b.kind===kind&&b.version===version),times=selected.flatMap(b=>b.times).sort((a,b)=>a-b);if(times.length!==30||selected.some(b=>b.pixels.sha256!==selected[0].pixels.sha256))throw Error('Amostras incompletas');summaries.push({cpu,kind,version,samples:times.length,p50:times[14],p95:times[28],p99:times[29],sha256:selected[0].pixels.sha256,moves:selected[0].moves});}
 const sha=b=>crypto.createHash('sha256').update(b).digest('hex');fs.writeFileSync('.cache/pinta-grid-ab.json',JSON.stringify({at:new Date().toISOString(),sourceBase:cp.execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),currentSourceSha256:sha(fs.readFileSync('packages/pinta/src/components/editor/mapTools/mapCanvas.ts')),referenceCommit:'0e377ac1b25f7fa1073e02dca048f12de4a278a7',browser:browser.version(),protocol:'ABBA; three warmup and 15 timed frames per block, await rAF before each; 30 samples per version/case/CPU; readback and GC outside measured rendering; no other session QA jobs',blocks,summaries},null,2)+'\n');console.log(JSON.stringify({summaries}));
 }finally{await browser.close();await new Promise(r=>server.close(r));}})().catch(e=>{console.error(e);process.exitCode=1;server.close();});
