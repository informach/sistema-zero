import { dirname,resolve } from 'node:path'
import { mkdir,writeFile } from 'node:fs/promises'
const root=resolve(import.meta.dir,'..'),baseline='0e377ac1b25f7fa1073e02dca048f12de4a278a7',out=resolve(import.meta.dir,'grid-profile-bundles')
await mkdir(out,{recursive:true})
for(const historical of [false,true]) {
 const name=historical?'reference':'current',entry=resolve(out,`${name}-entry.ts`)
 await writeFile(entry,`import * as bench from '../../packages/pinta/scripts/map-grid-probe'; import {runMapGeometryLegacyProbe,runMapGeometryRegionProbe} from '../../packages/pinta/scripts/map-geometry-probe'; Object.assign(window,{grid${historical?'Reference':'Current'}:{...bench,runMapGeometryLegacyProbe,runMapGeometryRegionProbe}});`)
 const plugin:Bun.BunPlugin={name:'actual-previous-canvas',setup(build){build.onLoad({filter:/[\\/]src[\\/]components[\\/]editor[\\/]mapTools[\\/]mapCanvas\.ts$/},args=>{const file=args.path.replaceAll('\\','/').split('/packages/pinta/')[1],p=Bun.spawnSync(['git','show',`${baseline}:packages/pinta/${file}`],{cwd:root,stdout:'pipe',stderr:'pipe'});if(p.exitCode)throw Error('Fonte anterior ausente');return{contents:p.stdout.toString(),loader:'ts',resolveDir:dirname(args.path)}})}}
 const built=await Bun.build({entrypoints:[entry],target:'browser',outdir:out,plugins:historical?[plugin]:[],minify:false,sourcemap:'external'})
 if(!built.success)throw new AggregateError(built.logs,'Compilação do laboratório falhou')
}
