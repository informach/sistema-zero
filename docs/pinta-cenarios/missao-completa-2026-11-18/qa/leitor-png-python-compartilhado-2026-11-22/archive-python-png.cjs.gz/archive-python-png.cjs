const fs=require('node:fs');
const path=require('node:path');
const {createHash}=require('node:crypto');
const {gzipSync}=require('node:zlib');
const root=path.resolve(__dirname,'..');
const target=path.join(root,'docs/pinta-cenarios/missao-completa-2026-11-18/qa/leitor-png-python-compartilhado-2026-11-22');
const reportPath='packages/studio/.cache/pinta-physical-regions-results/report.json';
const {stats}=JSON.parse(fs.readFileSync(path.join(root,reportPath),'utf8'));
if(stats.expected!==4||stats.unexpected||stats.flaky||stats.skipped)throw Error('Unexpected browser results');
const sha=b=>createHash('sha256').update(b).digest('hex');
const entries=[
 ['pinta-full.log','.cache/pinta-python-png-full.log'],
 ['focused.log','.cache/pinta-python-png-focused.log'],
 ['pinta-types.log','.cache/pinta-python-png-types.log'],
 ['biome.log','.cache/pinta-python-png-lint.log'],
 ['python-generated.log','.cache/pinta-python-png-generated.log'],
 ['js-generated.log','.cache/pinta-python-png-js-generated.log'],
 ['browser.log','.cache/pinta-python-png-browser.log'],
 ['physical-report.json',reportPath],
 ['environment.json','.cache/pinta-python-png-environment.json'],
 ['diff.log','.cache/pinta-python-png-diff.log'],
 ['archive-python-png.cjs','.cache/archive-pinta-python-png.cjs'],
];
const records=entries.map(([name,source])=>{const raw=fs.readFileSync(path.join(root,source)),gz=gzipSync(raw),file=name+'.gz';fs.writeFileSync(path.join(target,file),gz);return{file,bytes:gz.length,sha256:sha(gz),rawSha256:sha(raw)};});
const sources=['packages/pinta/src/export/pythonPngText.ts','packages/pinta/src/export/pythonPngText.test.ts'].map(file=>{const raw=fs.readFileSync(path.join(root,file));return{file,bytes:raw.length,sha256:sha(raw)};});
fs.writeFileSync(path.join(target,'index.json'),JSON.stringify({baseline:'d64fe70471f7eaed7e40a617c3ba799dc71d9e24',records,sources},null,2)+'\n');
console.log(JSON.stringify({records:records.length,sources:sources.length}));
