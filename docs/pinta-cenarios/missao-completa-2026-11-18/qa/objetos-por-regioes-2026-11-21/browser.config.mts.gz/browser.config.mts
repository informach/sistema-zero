import { resolve } from 'node:path'
import base from '../packages/studio/playwright.pinta-terrain.config'
const root=resolve(import.meta.dirname,'..'),port=Number(process.env.PINTA_E2E_PORT??5501),outputDir=resolve(root,'.cache/pinta-object-regions-browser-r4')
export default {
 ...base,
 testDir:resolve(root,'packages/studio/e2e'),
 testMatch:['pinta-level-design-scenes.flow.ts','pinta-resources-scenes.flow.ts','pinta-clipboard-regions-scenes.flow.ts'],
 outputDir,
 reporter:[['list'],['json',{outputFile:resolve(outputDir,'report.json')}]],
 webServer:{command:'node scripts/serve-e2e.ts',cwd:resolve(root,'packages/pinta'),env:{PINTA_E2E_PORT:String(port)},url:`http://127.0.0.1:${port}`,reuseExistingServer:false,timeout:120000},
}


