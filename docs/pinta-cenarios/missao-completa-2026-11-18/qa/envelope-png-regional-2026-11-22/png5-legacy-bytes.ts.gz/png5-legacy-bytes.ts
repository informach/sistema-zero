import {execFileSync} from 'node:child_process'
import {mkdirSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {createCanvas} from '@napi-rs/canvas'
import {pngWithPintaData} from '../packages/pinta/src/export/pngText'
const baseline='a3f9747bf'
mkdirSync('packages/pinta/.cache',{recursive:true})
writeFileSync('packages/pinta/.cache/png-text-before-5.ts',execFileSync('git',['show',baseline+':packages/pinta/src/export/pngText.ts']))
const old=await import('../packages/pinta/.cache/png-text-before-5.ts')
let cases=0;const digest=createHash('sha256')
for(let version=1;version<=4;version++)for(let seed=0;seed<64;seed++){
  const canvas=createCanvas(16,16),ctx=canvas.getContext('2d');ctx.fillStyle=`rgb(${seed},0,255)`;ctx.fillRect(0,0,16,16)
  const cover=new Uint8Array(canvas.toBuffer('image/png'))
  const data={format:'pinta',version,kind:'map',name:'Vila á🌳 "'+seed,scale:seed%4+1,layers:[{cells:[-1,0,4096,8192,16384],properties:{name:'a\nb',seed}}]}
  const expected=await old.pngWithPintaData(cover,data),actual=await pngWithPintaData(cover,data)
  if(!Buffer.from(expected).equals(Buffer.from(actual)))throw Error('Legacy PNG changed '+cases)
  digest.update(actual);cases++
}
for(const encode of [old.pngWithPintaData,pngWithPintaData]){
  const data={name:'before'},pending=encode(new Uint8Array(createCanvas(1,1).toBuffer('image/png')),data)
  data.name='after';digest.update(await pending)
}
const result={baseline,cases,versions:[1,2,3,4],pngBytesIdentical:true,sha256:digest.digest('hex')}
writeFileSync('.cache/png5-legacy-bytes.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
