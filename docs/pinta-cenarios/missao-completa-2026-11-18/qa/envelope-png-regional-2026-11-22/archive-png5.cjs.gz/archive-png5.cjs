const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),zlib=require('node:zlib');
const baseline='a3f9747bf',out='docs/pinta-cenarios/missao-completa-2026-11-18/qa/envelope-png-regional-2026-11-22/';
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex'),read=name=>fs.readFileSync('.cache/png5-'+name+'.log','utf8');
for(const [name,count]of [['pinta-full',2748],['core-full',3222],['focused',47]]){const text=read(name);if(!text.includes(count+' pass')||!text.includes('0 fail')||/[1-9]\d* skip/.test(text))throw Error(name+' incomplete');}
for(const name of ['core-types','pinta-types','studio-types','diff'])if(read(name).trim())throw Error(name+' not clean');
for(const name of ['legacy-timing-red','index-budget-red'])if(!read(name).includes('1 fail'))throw Error(name+' negative proof missing');
if(!read('biome').includes('Checked 8 files'))throw Error('Lint missing');
const legacy=JSON.parse(fs.readFileSync('.cache/png5-legacy-bytes.json'));if(legacy.cases!==256||!legacy.pngBytesIdentical)throw Error('Legacy comparison missing');
const rows=suites=>suites.flatMap(s=>[...(s.specs||[]).flatMap(s=>s.tests),...rows(s.suites||[])]);
const reports=[['packages/studio/.cache/pinta-physical-regions-results/report.json',61,'physical-report.json'],['packages/studio/.cache/pinta-integration-results/report.json',12,'integration-report.json']];
const artifacts=[];
for(const [file,expected]of reports){const report=JSON.parse(fs.readFileSync(file));if(report.stats.expected!==expected||report.stats.unexpected||report.stats.skipped||report.stats.flaky||rows(report.suites).some(test=>test.results.length!==1||test.results[0].status!=='passed'))throw Error('Browser incomplete '+file);for(const test of rows(report.suites))for(const a of test.results[0].attachments||[])if(a.name==='vila-dados5.png')artifacts.push(a);}
if(artifacts.length!==2)throw Error('PNG 5 artifacts missing');
fs.mkdirSync(out,{recursive:true});const records=[];
function add(raw,name){const bytes=zlib.gzipSync(raw),file=name+'.gz';fs.writeFileSync(out+file,bytes,{flag:'wx'});records.push({file,bytes:bytes.length,sha256:sha(bytes),rawBytes:raw.length,rawSha256:sha(raw)});}
for(const name of ['focused','pinta-full','core-full','core-types','pinta-types','studio-types','biome','browser-focused','browser','integration-browser','legacy-timing-red','index-budget-red','budget-focused','diff'])add(Buffer.from(read(name)),name+'.log');
for(const [file,,name]of reports)add(fs.readFileSync(file),name);
for(const [index,a]of artifacts.entries()){
  const raw=a.path?fs.readFileSync(a.path):Buffer.from(a.body,'base64');
  if(raw.subarray(1,4).toString()!=='PNG'||raw.readUInt32BE(16)!==512||raw.readUInt32BE(20)!==384||raw.subarray(37,41).toString()!=='iTXt')throw Error('Bad PNG artifact');
  const length=raw.readUInt32BE(33),json=zlib.inflateSync(raw.subarray(51,41+length),{maxOutputLength:16*1024*1024}),data=JSON.parse(json);
  if(data.version!==5||data.scene.version!==4||data.scene.layers.length!==18||data.scene.tilesets.length!==2||data.scene.physics!=='legacy'||data.scene.layers.find(l=>l.kind==='tiles').cells.encoding!=='i16le-base64-v1')throw Error('Bad PNG metadata');
  fs.writeFileSync('.cache/vila-dados5-'+index+'.png',raw);add(raw,'vila-dados5-'+index+'.png');add(json,'vila-dados5-'+index+'.json');
}
for(const name of ['png5-legacy-bytes.ts','png5-legacy-bytes.json','png5-legacy-bytes.log','archive-png5.cjs'])add(fs.readFileSync('.cache/'+name),name);
const files=[...new Set([...cp.execFileSync('git',['diff','--name-only','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n'),...cp.execFileSync('git',['ls-files','--others','--exclude-standard','--','*.ts','*.tsx'],{encoding:'utf8'}).trim().split('\n')].filter(Boolean))];
const sources=files.map(file=>({file,sha256:sha(fs.readFileSync(file)),...(cp.spawnSync('git',['cat-file','-e',baseline+':'+file]).status===0?{previousSha256:sha(cp.execFileSync('git',['show',baseline+':'+file]))}:{})}));
const count=text=>({pass:Number(text.match(/(\d+) pass/)?.[1]),fail:0,skipped:0,assertions:Number(text.match(/(\d+) expect\(\) calls/)?.[1]),files:Number(text.match(/across (\d+) files/)?.[1])});
const fixture='packages/pinta/src/export/__fixtures__/pinta-png4-reader.py.gz',raw=zlib.gunzipSync(fs.readFileSync(fixture));if(sha(raw)!=='76ab0c859b1226672428dd05335a45a9bc4b189d03223492a5672772c28f7c85')throw Error('Old reader changed');
fs.writeFileSync(out+'index.json',JSON.stringify({baseline,records,sources,previousPygameReader:{fixture,sourceRevision:baseline,rawSha256:sha(raw),rawBytes:raw.length},pinta:count(read('pinta-full')),core:count(read('core-full')),focused:count(read('focused')),browser:{pass:73,physical:61,integration:12,retries:0,profiles:['desktop','cpu-4x'],png5Artifacts:2,independentRealms:true},nativePygame:{ordinaryImageAccepted:true,previousMetadataReaderRefused:true,regionalGameplay:false},legacyBytes:{cases:256,identical:true},indexAdmission:{maxBytes:4*1024*1024,exactBoundaryAccepted:true,oversizeDecodes:0,remainingBudgetMayOnlyNarrow:true},publicPng5:false,worldLoader5:false,gameplayRuntime4:false,publicNative8:false,cloud7:false,additionalPhysicalDevices:false},null,2));
console.log(JSON.stringify({records:records.length,sources:sources.length,artifacts:artifacts.length}));
