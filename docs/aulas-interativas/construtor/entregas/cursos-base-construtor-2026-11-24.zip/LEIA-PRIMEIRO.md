# Cursos base do Construtor

Este pacote contém a autoria completa de Nave Contra Asteroides (9 aulas) e Patrulha Espacial (5 aulas), com roteiros, textos ElevenLabs, índices de edição, cadastro, manifestos, projetos, capas e cadernos visuais.

## Por onde começar

1. Abra `docs/aulas-interativas/construtor/producao-cursos-base-2026-11-24.md` para conferir a entrega, os testes e a relação com a proposta pedagógica aprovada, incluída em `proposta-cursos-base-2026-11-24.md`.
2. Em cada diretório de curso, leia `modulos.md` e `mapa-de-aulas.md` para consultar a progressão consolidada.
3. Consulte `passo-a-passo-do-projeto.pdf` e importe os `.szproject.json` quando quiser conferir uma etapa.
4. Use os `.roteiro.md`, masters `.elevenlabs.txt`, falas de personagem e `.edicao.json` para produzir as mídias.

Os textos estão completos; não são áudios sintetizados nem vídeos gravados. O cadastro e a publicação na plataforma ainda são etapas de produção. Os três modelos 3D são os provisórios aprovados; as artes e variações do Blender serão fornecidas por Helena.

Os caminhos originais do repositório foram mantidos. A pasta técnica inclui as fontes específicas desta autoria para consulta. Para regenerar ou executar os testes, use o checkout completo do repositório, com seus pacotes, fontes comuns, assets e dependências; este ZIP não é uma cópia autônoma do monorepo.

Repositório e alterações: https://github.com/informach/sistema-zero/pull/287

`SHA256SUMS.txt` permite conferir a integridade dos arquivos.
