# Etapas dos jogos do Construtor

Há 26 projetos 2D e 19 projetos 3D, em ordem de construção. O primeiro de cada pasta é o inicial; o último é o completo. Cada arquivo já inclui seus assets.

Importe um arquivo `.szproject.json` de cada vez no Estúdio. As versões intermediárias têm somente as regras construídas até aquela parte: um laser parado ou a ausência de pontos pode ser intencional. O mapa detalhado de aulas e partes está no pacote dos cursos.

No jogo completo 2D: Enter começa; setas movem; cada toque em Espaço dispara. Após o resultado, Enter volta à abertura e outro Enter começa novamente.

No jogo completo 3D: Enter começa; setas movem; cada toque em Espaço dispara. Após o resultado, use o botão Voltar ao início e pressione Enter para jogar novamente.

A meta é acertar vinte asteroides antes de perder três vidas. Asteroides que passam sem bater na nave não tiram vida. As escolhas de aparência não mudam essas regras.

`SHA256SUMS.txt` permite conferir a integridade dos arquivos.
